﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using SocialMarket.Models;
using SocialMarket.Repository;
using X.PagedList;
using SocialMarket.Utils;

namespace SocialMarket.Controllers
{
    public class HomeController : Controller
    {
        #region Home Site
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }
        #endregion

        #region Home Pessoa
        // GET: Painel Pessoa
        public ActionResult IndexPessoa(Compartilhamento compartilhamento,Pessoa pessoa, int pagina = 1)
        {
            pessoa = (Pessoa)Session["ObjetoPessoa"];
            if (Session["ObjetoPessoa"] != null)
            {

                return View(PostagemRepository.Feed(pessoa, compartilhamento).OrderByDescending(postagem => postagem.DataComp).OrderByDescending(postagem => postagem.Data).ToPagedList(pagina, 5));
            }
            else
            {
                return RedirectToAction("LoginPessoa", "Autenticacao");
            }
        }

        [HttpPost]
        public ActionResult IndexPessoa(Postagem postagem, Pessoa pessoa, Compartilhamento compartilhamento)
        {
            try
            {
                IEnumerable<Models.Postagem> listarPostagem = PostagemRepository.Feed(pessoa, compartilhamento).OrderBy(data => data.Data);
                List<Models.Postagem> postagens = new List<Models.Postagem>();
                foreach (Models.Postagem p in listarPostagem)
                {
                    postagens.Add(postagem);
                }

                return View(postagens);
            }
            catch
            {
                return View();
            }
        }

        #endregion

        #region Home Mercado

        public ActionResult IndexMercado(Mercado mercado, int pagina = 1)
        {
            mercado = (Mercado)Session["ObjetoMercado"];
            if (Session["ObjetoMercado"] != null)
            {
                return View(ProdutoRepository.GetAllProduto(mercado).OrderBy(produto => produto.Nome).ToPagedList(pagina, 5));
            }
            else
            {
                return RedirectToAction("LoginMercado", "Autenticacao");
            }

        }
       
        #endregion
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using SocialMarket.Models;
using SocialMarket.Repository;
using X.PagedList;
using SocialMarket.Utils;

namespace SocialMarket.Controllers
{
    public class PostagemController : Controller
    {
        #region Postagem

        public ActionResult ListarPostagem(Pessoa pessoa, int pagina = 1)
        {
            pessoa = (Pessoa)Session["ObjetoPessoa"];
            if (Session["ObjetoPessoa"] != null)
            {
                return View(PostagemRepository.GetAllPostagem(pessoa).OrderBy(postagem => postagem.Data).ToPagedList(pagina, 6));
            }
            else
            {
                return RedirectToAction("LoginPessoa", "Autenticacao");
            }
        }


        //GET: Painel/Criar Post
        public ActionResult CreatePostagem()
        {
            if (Session["ObjetoPessoa"] != null)
            {
                return View();
            }
            else
            {
                return RedirectToAction("LoginPessoa", "Autenticacao");
            }
        }

        //POST: CreatePostagem/Create
        [HttpPost]
        public ActionResult CreatePostagem(Postagem post, HttpPostedFileBase fileBase, Pessoa pessoa)
        {
            var repository = new PostagemRepository();

            pessoa = (Pessoa)Session["ObjetoPessoa"];
            repository.CreatePostagem(post, fileBase, pessoa);
            return RedirectToAction("IndexPessoa", "Home");

        }

        // GET: Painel/EditarPostagem
        public ActionResult EditPostagem(int id)
        {
            return View(PostagemRepository.GetPostagem(id));
        }

        //POST: EditarPosatgem/Edit
        [HttpPost]
        public ActionResult EditPostagem(FormCollection collection/*, Pessoa pessoa*/, HttpPostedFileBase fileBase)
        {
            try
            {
                Models.Postagem postagem = new Models.Postagem();
                //pessoa = (Pessoa)Session["ObjetoPessoa"];

                postagem.IdPostagem = Convert.ToInt32(collection["IdPostagem"]);
                //pessoa.IdPessoa = Convert.ToInt32(collection["IdPessoa"]);
                postagem.Conteudo = collection["Conteudo"];
                postagem.Midia = collection["Midia"];

                PostagemRepository.EditPostagem(postagem, fileBase);
                return RedirectToAction("IndexPessoa", "Home");

            }
            catch
            {
                return View();
            }
        }

        //GET: Painel/DeletePostagem
        public ActionResult DeletePostagem(int id)
        {
            return View(PostagemRepository.GetPostagem(id));
        }

        //POST: DeletePostagem/Delete
        [HttpPost]
        public ActionResult DeletePostagem(int id, FormCollection collection)
        {
            try
            {
                PostagemRepository.DeletePostagem(id);
                return RedirectToAction("ListarPostagem", "Postagem");
            }
            catch
            {
                return View();
            }
        }
        #endregion
    }
}
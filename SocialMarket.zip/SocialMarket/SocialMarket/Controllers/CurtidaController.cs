﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using SocialMarket.Models;
using SocialMarket.Repository;
using SocialMarket.Utils;


namespace SocialMarket.Controllers
{
    public class CurtidaController : Controller
    {
        public ActionResult CreteCurtida(int id, Pessoa pessoa, Postagem postagem)
        {
            if (Session["ObjetoPessoa"] != null)
            {
                pessoa = (Pessoa)Session["ObjetoPessoa"];
                var repository = new CurtidaRepository();

                bool tem = false;

                tem = CurtidaRepository.VerificaCurtida(id, postagem,  pessoa);

                if (tem == true)
                {
                    repository.DeleteCurtida(id, pessoa);
                     //repository.QuantidadeCurtida(id, postagem);
                    TempData["MensagemApagarCurtida"] = "Curtida removida com sucesso!";
                    return RedirectToAction("IndexPessoa", "Home");
                }
                else
                {
                    repository.CreateCurtida(id, pessoa);
                    //repository.QuantidadeCurtida(id, postagem);
                    TempData["MensagemCurtida"] = "Curtida feita com sucesso!";
                    return RedirectToAction("IndexPessoa", "Home");
                }
            }
            else
            {
                return RedirectToAction("LoginPessoa", "Autenticacao");
            }
        }

        public ActionResult CreteCurtidaComp(int id, Pessoa pessoa, Postagem postagem, Compartilhamento compartilhamento)
        {
            if (Session["ObjetoPessoa"] != null)
            {
                pessoa = (Pessoa)Session["ObjetoPessoa"];
                var repository = new CurtidaRepository();

                bool tem = false;

                tem = CurtidaRepository.VerificaCurtidaComp(id, postagem, pessoa);

                if (tem == true)
                {
                    repository.DeleteCurtidaComp(id, pessoa);
                    return RedirectToAction("IndexPessoa", "Home");
                }
                else
                {
                    repository.CreateCurtidaComp(id, pessoa, compartilhamento);
                    return RedirectToAction("IndexPessoa", "Home");
                }
            }
            else
            {
                return RedirectToAction("LoginPessoa", "Autenticacao");
            }
        }
    }
}
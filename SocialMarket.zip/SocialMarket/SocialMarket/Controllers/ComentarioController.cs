﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using SocialMarket.Models;
using SocialMarket.Repository;
using X.PagedList;
using SocialMarket.Utils;

namespace SocialMarket.Controllers
{
    public class ComentarioController : Controller
    {
        public ActionResult ListarComentario(int id, Pessoa pessoa, int pagina = 1, string busca = "")
        {
            pessoa = (Pessoa)Session["ObjetoPessoa"];
            ViewBag.Busca = busca;
            return View(ComentarioRepository.GetAllComentario(id).Where(nome => nome.NomeUsuario.Contains(busca))
                .OrderBy(data => data.Data)
                .ToPagedList(pagina, 5));
        }

        public ActionResult CreateComentario(Pessoa pessoa)
        {
            pessoa = (Pessoa)Session["ObjetoPessoa"];
            if (Session["ObjetoPessoa"] != null)
            {
                return View();
            }
            else
            {
                return RedirectToAction("LoginPessoa", "Autenticacao");
            }
        }

        [HttpPost]
        public ActionResult CreateComentario(int id, Comentario comentario, Pessoa pessoa)
        {
            var repository = new ComentarioRepository();
            pessoa = (Pessoa)Session["ObjetoPessoa"];
            repository.CreateComentario(id, comentario, pessoa);
            return RedirectToAction("IndexPessoa", "Home");

        }

        public ActionResult ExcluirComentario(int id, Pessoa pessoa)
        {
            try
            {
                pessoa = (Pessoa)Session["ObjetoPessoa"];
                ComentarioRepository.DeleteComentario(id, pessoa);
                TempData["MensagemAmigoRemovido"] = "O amigo foi removido com sucesso!";
                return RedirectToAction("ListarComentario", "Comentario");
            }
            catch
            {
                return View();
            }
        }
    }
}
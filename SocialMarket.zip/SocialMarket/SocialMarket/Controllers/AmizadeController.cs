﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using SocialMarket.Models;
using SocialMarket.Repository;
using X.PagedList;
using SocialMarket.Utils;

namespace SocialMarket.Controllers
{
    public class AmizadeController : Controller
    {
        public ActionResult AceitarPedidoAmizade(int id, Pessoa pessoa)
        {
            pessoa = (Pessoa)Session["ObjetoPessoa"];
            var repository = new AmizadeRepository();
            repository.AceitarPedidoAmizade(id, pessoa);
            TempData["MensagemPedidoAceito"] = "Solicitação de amizade aceita com sucesso!";
            return RedirectToAction("ListarPedidoAmizade", "Amizade");
        }

        public ActionResult RecusarPedidoAmizade(int id, Pessoa pessoa)
        {
            try
            {
                pessoa = (Pessoa)Session["ObjetoPessoa"];
                AmizadeRepository.RecusarPedidoAmizade(id, pessoa);
                TempData["MensagemPedidoRecusado"] = "Solicitação de amizade foi recusada com sucesso!";
                return RedirectToAction("ListarPedidoAmizade", "Amizade");
            }
            catch
            {
                return View();
            }
        }

        //Listar as solicitações de amizade (pendente)
        public ActionResult ListarPedidoAmizade(Amizade amizade, Pessoa pessoa, int pagina = 1, string busca = "")
        {
            if (Session["ObjetoPessoa"] != null)
            {
                pessoa = (Pessoa)Session["ObjetoPessoa"];
                ViewBag.Busca = busca;
                return View(AmizadeRepository.VisualizarPedidoAmizade(amizade, pessoa).Where(nome => nome.NomeUsuario.Contains(busca))
                    .OrderBy(data => data.Data)
                    .ToPagedList(pagina, 5));
            }
            else
            {
                return RedirectToAction("LoginPessoa", "Autenticacao");
            }
        }

        //Lista com todas as pessoas disponiveis para enviar solicitação de amizade
        public ActionResult ListarPessoa(Pessoa pessoa, int pagina = 1, string busca = "")
        {
            if (Session["ObjetoPessoa"] != null)
            {
                pessoa = (Pessoa)Session["ObjetoPessoa"];
                ViewBag.Busca = busca;
                return View(AmizadeRepository.ListarPessoa(pessoa).Where(nome => nome.NomeUsuario.Contains(busca))
                    .OrderBy(nome => nome.Nome)
                    .ToPagedList(pagina, 5));
            }
            else
            {
                return RedirectToAction("LoginPessoa", "Autenticacao");
            }
        }

        //Listar todos os meus amigos
        public ActionResult ListarAmigo(Amizade amigo, Pessoa pessoa, int pagina = 1, string busca = "")
        {
            if (Session["ObjetoPessoa"] != null)
            {
                pessoa = (Pessoa)Session["ObjetoPessoa"];
                ViewBag.Busca = busca;
                return View(AmizadeRepository.ListarAmigo(amigo, pessoa).Where(nome => nome.NomeUsuario.Contains(busca))
                    .OrderBy(nome => nome.NomeUsuario)
                    .ToPagedList(pagina, 5));
            }
            else
            {
                return RedirectToAction("LoginPessoa", "Autenticacao");
            }
        }

        public ActionResult EnviarPedidoAmizade(int id, Pessoa pessoa, Amizade amizade)
        {
            bool tem = false;

            pessoa = (Pessoa)Session["ObjetoPessoa"];
            var repository = new AmizadeRepository();

            tem = AmizadeRepository.VerificarPedidoAmizadeExistente(id, pessoa);

            if (tem == true)
            {
                TempData["MensgaemVerificarPedidoExistente"] = "Um pedido de solicitação de amizade já foi enviado para esta pessoa!";
                return RedirectToAction("ListarPessoa", "Amizade");
            }
            else
            {
                repository.CreateAmizade(id, amizade, pessoa);
                TempData["MensagemPedidoEnviado"] = "A solicitação foi enviada com sucesso!";
                return RedirectToAction("ListarPessoa", "Amizade");
            }
        }

        public ActionResult ExcluirAmigo(int id, Pessoa pessoa)
        {
            try
            {
                pessoa = (Pessoa)Session["ObjetoPessoa"];
                AmizadeRepository.DeleteAmigo(id, pessoa);
                TempData["MensagemAmigoRemovido"] = "O amigo foi removido com sucesso!";
                return RedirectToAction("ListarAmigo", "Amizade");
            }
            catch
            {
                return View();
            }
        }
    }
}

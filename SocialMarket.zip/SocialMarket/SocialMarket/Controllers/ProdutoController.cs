﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using SocialMarket.Models;
using SocialMarket.Repository;
using System.Data.SqlClient;
using System.IO;
using SocialMarket.Utils;
using System.Web.Mvc;
using X.PagedList;

namespace SocialMarket.Controllers
{
    public class ProdutoController : Controller
    {
        //Listar todos os produtos do mercado para poder editar
        public ActionResult ListarProduto(Mercado mercado, int pagina = 1)
        {
            mercado = (Mercado)Session["ObjetoMercado"];
            if (Session["ObjetoMercado"] != null)
            {
                return View(ProdutoRepository.GetAllProduto(mercado).OrderBy(produto => produto.Nome).ToPagedList(pagina, 5));
            }
            else
            {
                return RedirectToAction("LoginMercado", "Autenticacao");
            }

        }

        public ActionResult CreateProduto()
        {
            if (Session["ObjetoMercado"] != null)
            {
                return View();
            }
            else
            {
                return RedirectToAction("LoginMercado", "Autenticacao");
            }
        }

        //POST: CreateProduto/Create
        [HttpPost]
        public ActionResult CreateProduto(Produto produto, Mercado mercado, HttpPostedFileBase fileBase)
        {
            bool tem = false;

            tem = ProdutoRepository.VerificarProdutoCadastradoMercado(produto);

            if (tem == true)
            {
                ModelState.AddModelError("Fabricante", "Produto já cadastrado para este fabricante!");
                return View();
            }
            else
            {
                var repository = new ProdutoRepository();

                mercado = (Mercado)Session["ObjetoMercado"];
                repository.CreateProduto(produto, mercado, fileBase);
                //ModelState.Clear();
                //ViewBag.Message = pessoa.Nome + " cadastrado com sucesso! Efetue o Login para entrar no site.";
                return RedirectToAction("IndexMercado", "Home");
            }
        }

        // GET: Painel/Editar Produto
        public ActionResult EditProduto(int id)
        {
            return View(ProdutoRepository.GetProduto(id));
        }

        //POST: EditProduto/Edit
        [HttpPost]
        public ActionResult EditProduto(FormCollection collection, HttpPostedFileBase fileBase, Produto produto)
        {
            bool tem = false;

            tem = ProdutoRepository.VerificarProdutoCadastradoMercado(produto);

            if (tem == true)
            {
                ModelState.AddModelError("Fabricante", "Produto já cadastrado para este fabricante!");
                return View();
            }
            else
            {
                try
                {
                    produto.IdProduto = Convert.ToInt32(collection["IdProduto"]);
                    produto.Nome = collection["Nome"];
                    produto.Estoque = Convert.ToInt32(collection["Estoque"]);
                    produto.Preco = Convert.ToDecimal(collection["Preco"]);

                    ProdutoRepository.EditProduto(produto, fileBase);
                    return RedirectToAction("IndexMercado", "Home");
                }
                catch
                {
                    return View();
                }
            }
        }

        //GET: Produto/DeleteProduto
        public ActionResult DeleteProduto(int id)
        {
            return View(ProdutoRepository.GetProduto(id));
        }

        //POST: DeleteProduto/Delete
        [HttpPost]
        public ActionResult DeleteProduto(int id, FormCollection collection)
        {
            try
            {
                ProdutoRepository.DeleteProduto(id);
                return RedirectToAction("IndexMercado", "Home");
            }
            catch
            {
                return View();
            }
        }
    }
}
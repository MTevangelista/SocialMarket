﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using SocialMarket.Models;
using SocialMarket.Repository;
using X.PagedList;
using SocialMarket.Utils;

namespace SocialMarket.Controllers
{
    public class ListaDeCompraController : Controller
    {
        public ActionResult VerItensDeCompra(Pessoa pessoa, int pagina = 1, string busca = "")
        {
            if (Session["ObjetoPessoa"] != null)
            {
                pessoa = (Pessoa)Session["ObjetoPessoa"];
                ViewBag.Busca = busca;
                return View(ListaDeCompraRepository.GetAllItemDeCompra(pessoa).Where(nome => nome.Item.Contains(busca))
                    .OrderBy(data => data.Data)
                    .ToPagedList(pagina, 5));
            }
            else
            {
                return RedirectToAction("LoginPessoa", "Autenticacao");
            }
        }

        public ActionResult CreateItemDeCompra(Pessoa pessoa)
        {
            pessoa = (Pessoa)Session["ObjetoPessoa"];
            if (Session["ObjetoPessoa"] != null)
            {
                return View();
            }
            else
            {
                return RedirectToAction("LoginPessoa", "Autenticacao");
            }
        }

        [HttpPost]
        public ActionResult CreateItemDeCompra(ListaDeCompra listaDeCompra, Pessoa pessoa)
        
{
            var repository = new ListaDeCompraRepository();

            pessoa = (Pessoa)Session["ObjetoPessoa"];
            repository.CreateItemDeCompra(listaDeCompra, pessoa);
            return RedirectToAction("VerItensDeCompra", "ListaDeCompra");
        }

        public ActionResult EditItem(int id)
        {
            return View(ListaDeCompraRepository.GetItemDeCompra(id));
        }

        [HttpPost]
        public ActionResult EditItem(int id, FormCollection collection)
        {
            try
            {
                Models.ListaDeCompra listaDeCompra = new ListaDeCompra();

                listaDeCompra.IdPessoa = Convert.ToInt32(collection["IdPessoa"]);
                listaDeCompra.IdItem = Convert.ToInt32(collection["IdItem"]);
                listaDeCompra.Descricao = collection["Descricao"];
                listaDeCompra.Item = collection["Item"];
                listaDeCompra.Quantidade = Convert.ToInt32(collection["Quantidade"]);

                ListaDeCompraRepository.EditItem(id, listaDeCompra);
                return RedirectToAction("VerItensDeCompra", "ListaDeCompra");

            }
            catch
            {
                return View();
            }
        }

        public ActionResult DeleteItemDeCompra(int id)
        {
            return View(ListaDeCompraRepository.GetItemDeCompra(id));
        }

        [HttpPost]
        public ActionResult DeleteItemDeCompra(int id, FormCollection collection)
        {
            try
            {
                ListaDeCompraRepository.DeleteItemDeCompra(id);
                return RedirectToAction("VerItensDeCompra", "ListaDeCompra");
            }
            catch
            {
                return View();
            }
        }
    }
}
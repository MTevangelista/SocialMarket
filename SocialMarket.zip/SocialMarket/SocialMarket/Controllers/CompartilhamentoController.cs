﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using SocialMarket.Models;
using SocialMarket.Repository;
using X.PagedList;
using SocialMarket.Utils;

namespace SocialMarket.Controllers
{
    public class CompartilhamentoController : Controller
    {
        public ActionResult CreateCompartilhamento(Pessoa pessoa, int id)
        {
            if (Session["ObjetoPessoa"] != null)
            {
                pessoa = (Pessoa)Session["ObjetoPessoa"];
                var repository = new CompartilhamentoRepository();
                repository.CreateCompartilhamento(id, pessoa);
                TempData["MensagemComp"] = "Postagem compartilhada com sucesso!";
                return RedirectToAction("IndexPessoa", "Home");
            }
            else
            {
                return RedirectToAction("LoginPessoa", "Autenticacao");
            }
        }
    }
}
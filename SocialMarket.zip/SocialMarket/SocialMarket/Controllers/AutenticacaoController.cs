﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using SocialMarket.Models;
using SocialMarket.Repository;
using SocialMarket.Utils;
using X.PagedList;

namespace SocialMarket.Controllers
{
    public class AutenticacaoController : Controller
    {
        #region CRUD Pessoa
        public ActionResult ConsultarMercado(int pagina = 1, string busca = "")
        {
            ViewBag.Busca = busca;
            return View(PessoaRepository.ConsultarMercado().Where(nome => nome.NomeUsuario.Contains(busca))
                .OrderBy(mercado => mercado.NomeUsuario)
                .ToPagedList(pagina, 5));
        }

        public ActionResult ConsultarPrecoProduto(Mercado mercado, int pagina = 1, string busca = "")
        {
            mercado = (Mercado)Session["ObjetoMercado"];
            ViewBag.Busca = busca;
            return View(PessoaRepository.ConsultarPrecoProduto(mercado).Where(nome => nome.Nome.Contains(busca))
                .OrderBy(produto => produto.Nome)
                .ToPagedList(pagina, 3));
        }

        public ActionResult ListarDadoPessoa(Pessoa pessoa)
        {
            pessoa = (Pessoa)Session["ObjetoPessoa"];
            if (Session["ObjetoPessoa"] != null)
            {
                return View(PessoaRepository.GetAllPessoa(pessoa));
            }
            else
            {
                return RedirectToAction("LoginPessoa", "Autenticacao");
            }
        }

        //GET: Autenticacao/CadastrarPessoa
        public ActionResult CadastrarPessoa()
        {
            return View();
        }

        //POST: CadastrarPessoa/Create
        [HttpPost]
        public ActionResult CadastrarPessoa(Pessoa pessoa)
        {
            bool email = false;
            bool nomeUsuario = false;
            bool cpf = false;

            email = PessoaRepository.VerificarCadastroExistentePessoaEmail(pessoa);
            nomeUsuario = PessoaRepository.VerificarCadastroExistentePessoaNomeUsuario(pessoa);
            cpf = PessoaRepository.VerificarCadastroExistentePessoaCPF(pessoa);

            if (ModelState.IsValid)
            {
                if ((email == true) || (nomeUsuario == true) || (cpf == true))
                {
                    if (email == true)
                    {
                        ModelState.AddModelError("Email", " Email existente! Por favor, informe outro Email.");
                    }
                    if (nomeUsuario == true)
                    {
                        ModelState.AddModelError("NomeUsuario", " Nome de Usuario existente! Por favor, informe outro Nome de Usuario.");
                    }
                    if (cpf == true)
                    {
                        ModelState.AddModelError("CPF", " CPF existente! Por favor, informe outro CPF.");
                    }
                }
                else
                {
                    var repository = new PessoaRepository();

                    repository.CreatePessoa(new Pessoa()
                    {
                        Nome = pessoa.Nome,
                        NomeUsuario = pessoa.NomeUsuario,
                        Email = pessoa.Email,
                        Senha = Hash.GerarHash(pessoa.Senha),
                        CPF = pessoa.CPF
                    });
                    TempData["MensagemCadastroRealizado"] = "A sua conta foi cadastrada com sucesso";
                    return RedirectToAction("LoginPessoa", "Autenticacao");
                }
            }
            return View(pessoa);
        }

        // GET: Autenticacao/EditarPessoa
        public ActionResult EditPessoa(int id)
        {
            return View(PessoaRepository.GetPessoa(id));
        }

        //POST: EditarPessoa/Edit
        [HttpPost]
        public ActionResult EditPessoa(FormCollection collection)
        {
            try
            {
                Models.Pessoa pessoa = new Models.Pessoa();

                pessoa.IdPessoa = Convert.ToInt32(collection["IdPessoa"]);
                pessoa.Nome = collection["Nome"];
                pessoa.NomeUsuario = collection["NomeUsuario"];
                pessoa.Email = collection["Email"];
                pessoa.ConfirmEmail = collection["Email"];
                pessoa.Senha = Hash.GerarHash(collection["Senha"]);
                pessoa.ConfirmSenha = collection["Senha"];
                pessoa.CPF = collection["CPF"];

                PessoaRepository.EditPessoa(pessoa);
                return RedirectToAction("ListarDadoPessoa", "Autenticacao");
            }
            catch
            {
                return View();
            }
        }

        // GET: Autenticacao/DeletePessoa
        public ActionResult DeletePessoa(int id)
        {
            return View(PessoaRepository.GetPessoa(id));
        }

        //POST: DeletePessoa/Delete
        [HttpPost]
        public ActionResult DeletePessoa(int id, FormCollection collection)
        {
            try
            {
                PessoaRepository.DeletePessoa(id);
                return RedirectToAction("Index", "Home");
            }
            catch
            {
                return View();
            }
        }

        #endregion

        #region CRUD Mercado

        public ActionResult ListarMercado(Mercado mercado)
        {
            mercado = (Mercado)Session["ObjetoMercado"];
            if (Session["ObjetoMercado"] != null)
            {
                return View(MercadoRepository.GetAllMercado(mercado));
            }
            else
            {
                return RedirectToAction("LoginMercado", "Autenticacao");
            }
        }

        //GET: Autentificacao/CadastrarMercado
        public ActionResult CadastrarMercado()
        {
            return View();
        }

        //POST: CadastrarMercado/Create
        [HttpPost]
        public ActionResult CadastrarMercado(Mercado mercado)
        {
            bool email = false;
            bool nomeUsuario = false;
            bool telefone = false;
            bool cnpj = false;

            email = MercadoRepository.VerificarCadastroExistenteMercadoEmail(mercado);
            nomeUsuario = MercadoRepository.VerificarCadastroExistenteMercadoNomeUsuario(mercado);
            telefone = MercadoRepository.VerificarCadastroExistenteMercadoTelefone(mercado);
            cnpj = MercadoRepository.VerificarCadastroExistenteMercadoCNPJ(mercado);

            if (ModelState.IsValid)
            {
                if ((email == true) || (nomeUsuario == true) || (telefone == true) || (cnpj == true))
                {
                    if (email == true)
                    {
                        ModelState.AddModelError("Email", " Email existente! Por favor, informe outro Email.");
                    }
                    if (nomeUsuario == true)
                    {
                        ModelState.AddModelError("NomeUsuario", " NomeUsuario existente! Por favor, informe outro NomeUsuario.");
                    }
                    if (telefone == true)
                    {
                        ModelState.AddModelError("Telefone", " Telefone existente! Por favor, informe outro Telefone.");
                    }
                    if (cnpj == true)
                    {
                        ModelState.AddModelError("CNPJ", " CNPJ existente! Por favor, informe outro CNPJ.");
                    }
                }
                else
                {
                    var repository = new MercadoRepository();

                    repository.CreateMercado(new Mercado()
                    {
                        Nome = mercado.Nome,
                        NomeUsuario = mercado.NomeUsuario,
                        Email = mercado.Email,
                        Senha = Hash.GerarHash(mercado.Senha),
                        Telefone = mercado.Telefone,
                        CNPJ = mercado.CNPJ,
                        CEP = mercado.CEP
                    });
                    TempData["MensagemCadastroMercado Realizado"] = "A sua conta foi cadastrada com sucesso";
                    return RedirectToAction("LoginMercado", "Autenticacao");
                }
            }
            return View(mercado);
        }

        // GET: Autenticacao/EditarMercado
        public ActionResult EditMercado(int id)
        {
            return View(MercadoRepository.GetMercado(id));
        }

        //POST: EditarMercado/Edit
        [HttpPost]
        public ActionResult EditMercado(FormCollection collection)
        {
            try
            {
                Mercado mercado = new Mercado();

                mercado.IdMercado = Convert.ToInt32(collection["IdMercado"]);
                mercado.Nome = collection["Nome"];
                mercado.NomeUsuario = collection["NomeUsuario"];
                mercado.Email = collection["Email"];
                mercado.Senha = Hash.GerarHash(collection["Senha"]);
                mercado.Telefone = collection["Telefone"];
                mercado.CNPJ = collection["CNPJ"];
                mercado.CEP = collection["CEP"];

                MercadoRepository.EditMercado(mercado);
                return RedirectToAction("ListarMercado", "Autenticacao");
            }
            catch
            {
                return View();
            }
        }

        //GET: Autenticacao/DeleteMercado
        public ActionResult DeleteMercado(int id)
        {
            return View(MercadoRepository.GetMercado(id));
        }

        //POST: DeletMercado/Delete
        [HttpPost]
        public ActionResult DeleteMercado(int id, FormCollection collection)
        {
            try
            {
                MercadoRepository.DeleteMercado(id);
                return RedirectToAction("Index", "Home");
            }
            catch
            {
                return View();
            }
        }

        #endregion

        #region LOGIN Pessoa e Mercado

        public ActionResult Logout()
        {
            Session.RemoveAll();
            return RedirectToAction("Index", "Home");
        }

        //GET: Login/Pessoa
        public ActionResult LoginPessoa()
        {
            return View();
        }

        //POST: Login/Pessoa
        [HttpPost]
        public ActionResult LoginPessoa(Pessoa pessoa)
        {
            var repository = new PessoaRepository();

            Pessoa userPessoa = repository.VerificarLoginPessoa(pessoa);

            if (userPessoa != null)
            {
                Session["ObjetoPessoa"] = pessoa;
                Session["NomeUsuario"] = pessoa.NomeUsuario;
                return RedirectToAction("IndexPessoa", "Home");
            }
            else
            {
                TempData["MensagemLoginPessoaInválido"] = "Nome de Usuário ou Senha incorretos!";
                return View(pessoa);
            }
        }

        //GET: Login/Mercado
        public ActionResult LoginMercado()
        {
            return View();
        }

        //POST: Login/Mercado
        [HttpPost]
        public ActionResult LoginMercado(Mercado mercado)
        {
            var repository = new MercadoRepository();
            Mercado userMercado = repository.VerificarLoginMercado(mercado);

            if (userMercado != null)
            {
                Session["ObjetoMercado"] = mercado;
                Session["NomeUsuario"] = mercado.NomeUsuario;
                return RedirectToAction("IndexMercado", "Home");
            }
            else
            {
                TempData["MensagemLoginMercadoInválido"] = "Nome de Usuário ou Senha incorretos!";
                return View(mercado);
            }
        }
        #endregion
    }
}
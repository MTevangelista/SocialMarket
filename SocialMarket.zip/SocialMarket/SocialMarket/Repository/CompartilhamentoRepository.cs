﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using SocialMarket.Models;
using System.IO;
using SocialMarket.Utils;

namespace SocialMarket.Repository
{
    public class CompartilhamentoRepository
    {
        internal void CreateCompartilhamento(int id, Pessoa pessoa)
        {
            var ConnectionString = DAO.CaminhoBanco();

            using (var Connection = new SqlConnection(ConnectionString))
            {
                var CommandText = "INSERT INTO Compartilhamento(IdPostagemPostou, IdPessoaRepostou, DataComp) VALUES (@IdPostagemPostou, @IdPessoaRepostou, @DataComp)";
                var InsertCommand = new SqlCommand(CommandText, Connection);

                InsertCommand.Parameters.AddWithValue("IdPostagemPostou", id);
                InsertCommand.Parameters.AddWithValue("IdPessoaRepostou", pessoa.IdPessoa);
                InsertCommand.Parameters.AddWithValue("DataComp", DateTime.Now);

                try
                {
                    Connection.Open();
                    InsertCommand.ExecuteNonQuery();
                }
                catch (SqlException se)
                {
                    throw new Exception(se.Message);
                }
                catch (System.Exception e)
                {
                    throw new Exception(e.Message);
                }
                finally
                {
                    Connection.Close();
                }
            }
        }
    }
}
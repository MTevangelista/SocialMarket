﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using SocialMarket.Models;
using System.IO;
using SocialMarket.Utils;

namespace SocialMarket.Repository
{
    public class CurtidaRepository
    {
        #region Curtida Postagem
        internal void QuantidadeCurtida(int id, Postagem postagem)
        {
            var ConnectionString = DAO.CaminhoBanco();

            using (var Connection = new SqlConnection(ConnectionString))
            {
                var CommandText = $"SELECT * FROM CurtidaPost WHERE IdPostagem = {id}";
                var SelectCommand = new SqlCommand(CommandText, Connection);

                try
                {
                    Connection.Open();

                    using (var reader = SelectCommand.ExecuteReader(CommandBehavior.CloseConnection))
                    {
                        while (reader.Read())
                        {
                            postagem.QuantidadeCurtida = postagem.QuantidadeCurtida + 1;
                        }
                    }
                }
                catch (SqlException se)
                {
                    throw new Exception(se.Message);
                }
                catch (System.Exception e)
                {
                    throw new Exception(e.Message);
                }
                finally
                {
                    Connection.Close();
                }
            }
        }

        internal void CreateCurtida(int id, Pessoa pessoa)
        {
            var ConnectionString = DAO.CaminhoBanco();

            using (var Connection = new SqlConnection(ConnectionString))
            {
                var CommandText = "INSERT INTO CurtidaPost(IdPostagem, IdPessoaCurtiu) VALUES (@IdPostagem, @IdPessoaCurtiu)";
                var InsertCommand = new SqlCommand(CommandText, Connection);

                InsertCommand.Parameters.AddWithValue("IdPostagem", id);
                InsertCommand.Parameters.AddWithValue("IdPessoaCurtiu", pessoa.IdPessoa);

                try
                {
                    Connection.Open();
                    InsertCommand.ExecuteNonQuery();
                }
                catch (SqlException se)
                {
                    throw new Exception(se.Message);
                }
                catch (System.Exception e)
                {
                    throw new Exception(e.Message);
                }
                finally
                {
                    Connection.Close();
                }

            }
        }

        internal void DeleteCurtida(int id, Pessoa pessoa)
        {
            var ConnectionString = DAO.CaminhoBanco();

            using (var Connection = new SqlConnection(ConnectionString))
            {
                var CommandText = $"DELETE FROM CurtidaPost WHERE IdPessoaCurtiu = {pessoa.IdPessoa} AND IdPostagem = {id}";
                var DeleteCommand = new SqlCommand(CommandText, Connection);

                try
                {
                    Connection.Open();
                    DeleteCommand.ExecuteNonQuery();
                }
                catch (SqlException se)
                {
                    throw new Exception("Erro ao tentar atualizar dados " + se.Message);
                }
                catch (System.Exception e)
                {
                    throw new Exception("Erro inesperado " + e.Message);
                }
                finally
                {
                    Connection.Close();
                }
            }
        }

        public static bool VerificaCurtida(int id, Postagem postagem,Pessoa pessoa)
        {
            var ConnectionString = DAO.CaminhoBanco();

            bool tem = false;

            using (var Connection = new SqlConnection(ConnectionString))
            {
                var CommandText = $"SELECT * FROM CurtidaPost WHERE IdPessoaCurtiu = {pessoa.IdPessoa} and CurtidaPost.IdPostagem = {id}";
                var SelectCommand = new SqlCommand(CommandText, Connection);

                try
                {
                    Connection.Open();

                    using (var reader = SelectCommand.ExecuteReader(CommandBehavior.CloseConnection))
                    {
                        if (reader.HasRows)
                        {
                            tem = true;
                        }
                    }
                }
                catch (SqlException se)
                {
                    throw new Exception(se.Message);
                }
                catch (System.Exception e)
                {
                    throw new Exception(e.Message);
                }
                finally
                {
                    Connection.Close();
                }
                return tem;
            }
        }
        
#endregion

        #region Curtida Compartilhamento
        internal void QuantidadeCurtidaComp(int id, Postagem postagem)
        {
            var ConnectionString = DAO.CaminhoBanco();

            using (var Connection = new SqlConnection(ConnectionString))
            {
                var CommandText = $"SELECT * FROM CurtidaComp WHERE IdPostagem = {id}";
                var SelectCommand = new SqlCommand(CommandText, Connection);

                try
                {
                    Connection.Open();

                    using (var reader = SelectCommand.ExecuteReader(CommandBehavior.CloseConnection))
                    {
                        while (reader.Read())
                        {
                            postagem.QuantidadeCurtida = postagem.QuantidadeCurtida + 1;
                        }
                    }
                }
                catch (SqlException se)
                {
                    throw new Exception(se.Message);
                }
                catch (System.Exception e)
                {
                    throw new Exception(e.Message);
                }
                finally
                {
                    Connection.Close();
                }
            }
        }

        internal void CreateCurtidaComp(int id, Pessoa pessoa, Compartilhamento compartilhamento)
        {
            var ConnectionString = DAO.CaminhoBanco();

            using (var Connection = new SqlConnection(ConnectionString))
            {
                var CommandText = "INSERT INTO CurtidaComp (IdPostagem, IdPessoaCurtiu, IdUsuarioRepostou) VALUES (@IdPostagem, @IdPessoaCurtiu, @IdUsuarioRepostou)";
                var InsertCommand = new SqlCommand(CommandText, Connection);

                InsertCommand.Parameters.AddWithValue("IdPostagem", id);
                InsertCommand.Parameters.AddWithValue("IdPessoaCurtiu", pessoa.IdPessoa);
                InsertCommand.Parameters.AddWithValue("IdUsuarioRepostou", compartilhamento.IdPessoaRepostou);

                try
                {
                    Connection.Open();
                    InsertCommand.ExecuteNonQuery();
                }
                catch (SqlException se)
                {
                    throw new Exception(se.Message);
                }
                catch (System.Exception e)
                {
                    throw new Exception(e.Message);
                }
                finally
                {
                    Connection.Close();
                }

            }
        }

        internal void DeleteCurtidaComp(int id, Pessoa pessoa)
        {
            var ConnectionString = DAO.CaminhoBanco();

            using (var Connection = new SqlConnection(ConnectionString))
            {
                var CommandText = $"DELETE FROM CurtidaComp WHERE IdPessoaCurtiu = {pessoa.IdPessoa} AND IdPostagem = {id}";
                var DeleteCommand = new SqlCommand(CommandText, Connection);

                try
                {
                    Connection.Open();
                    DeleteCommand.ExecuteNonQuery();
                }
                catch (SqlException se)
                {
                    throw new Exception("Erro ao tentar atualizar dados " + se.Message);
                }
                catch (System.Exception e)
                {
                    throw new Exception("Erro inesperado " + e.Message);
                }
                finally
                {
                    Connection.Close();
                }
            }
        }

        public static bool VerificaCurtidaComp(int id, Postagem postagem, Pessoa pessoa)
        {
            var ConnectionString = DAO.CaminhoBanco();

            bool tem = false;

            using (var Connection = new SqlConnection(ConnectionString))
            {
                var CommandText = $"SELECT * FROM CurtidaComp WHERE IdPessoaCurtiu = {pessoa.IdPessoa} and CurtidaComp.IdPostagem = {id}";
                var SelectCommand = new SqlCommand(CommandText, Connection);

                try
                {
                    Connection.Open();

                    using (var reader = SelectCommand.ExecuteReader(CommandBehavior.CloseConnection))
                    {
                        if (reader.HasRows)
                        {
                            tem = true;
                        }
                    }
                }
                catch (SqlException se)
                {
                    throw new Exception(se.Message);
                }
                catch (System.Exception e)
                {
                    throw new Exception(e.Message);
                }
                finally
                {
                    Connection.Close();
                }
                return tem;
            }
        }
        #endregion
    }
}
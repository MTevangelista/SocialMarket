﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using SocialMarket.Models;
using System.IO;
using SocialMarket.Utils;

namespace SocialMarket.Repository
{
    public class ProdutoRepository
    {
        public static IEnumerable<Produto> GetAllProduto(Mercado mercado)
        {
            var ConnectionString = DAO.CaminhoBanco();

            using (var Connection = new SqlConnection(ConnectionString))
            {
                var CommandText = $"SELECT * FROM Produto WHERE IdMercado = {mercado.IdMercado}";
                var SelectCommand = new SqlCommand(CommandText, Connection);

                Produto produto = null;
                var produtos = new List<Produto>();

                try
                {
                    Connection.Open();

                    using (var reader = SelectCommand.ExecuteReader(CommandBehavior.CloseConnection))
                    {
                        while (reader.Read())
                        {
                            produto = new Produto();

                            produto.IdProduto = (int)reader["IdProduto"];
                            produto.IdMercado = (int)reader["IdMercado"];
                            produto.Nome = reader["Nome"].ToString();
                            produto.Fabricante = reader["Fabricante"].ToString();
                            produto.Estoque = (int)reader["Estoque"];
                            produto.Preco = (decimal)reader["Preco"];

                            produtos.Add(produto);
                        }
                    }
                }
                catch (SqlException se)
                {
                    throw new Exception(se.Message);
                }
                catch (System.Exception e)
                {
                    throw new Exception(e.Message);
                }
                finally
                {
                    Connection.Close();
                }
                return produtos;
            }
        }

        public static Produto GetProduto(int id)
        {
            var ConnectionString = DAO.CaminhoBanco();

            using (var Connection = new SqlConnection(ConnectionString))
            {
                var CommandText = $"SELECT * FROM Produto WHERE IdProduto = {id}";
                var SelectCommand = new SqlCommand(CommandText, Connection);

                Produto produto = null;

                try
                {
                    Connection.Open();

                    using (var reader = SelectCommand.ExecuteReader(CommandBehavior.CloseConnection))
                    {
                        while (reader.Read())
                        {
                            produto = new Produto();

                            produto.IdProduto = (int)reader["IdProduto"];
                            produto.IdMercado = (int)reader["IdMercado"];
                            produto.Nome = reader["Nome"].ToString();
                            produto.Fabricante = reader["Fabricante"].ToString();
                            produto.Estoque = (int)reader["Estoque"];
                            produto.Preco = (decimal)reader["Preco"];
                        }
                    }
                }
                catch (SqlException se)
                {
                    throw new Exception(se.Message);
                }
                catch (System.Exception e)
                {
                    throw new Exception(e.Message);
                }
                finally
                {
                    Connection.Close();
                }
                return produto;
            }
        }

        internal void CreateProduto(Models.Produto produto, Mercado mercado, HttpPostedFileBase fileBase)
        {
            var ConnectionString = DAO.CaminhoBanco();

            using (var Connection = new SqlConnection(ConnectionString))
            {
                var CommandText = "INSERT INTO Produto (IdMercado, Nome, Fabricante, Estoque, Preco) VALUES (@IdMercado, @Nome, @Fabricante, @Estoque, @Preco)";
                var InsertCommand = new SqlCommand(CommandText, Connection);

                InsertCommand.Parameters.AddWithValue("IdMercado", mercado.IdMercado);
                InsertCommand.Parameters.AddWithValue("Nome", produto.Nome);
                InsertCommand.Parameters.AddWithValue("Fabricante", produto.Fabricante);
                InsertCommand.Parameters.AddWithValue("Estoque", produto.Estoque);
                InsertCommand.Parameters.AddWithValue("Preco", produto.Preco);

                try
                {
                    Connection.Open();
                    InsertCommand.ExecuteNonQuery();
                }
                catch (SqlException se)
                {
                    throw new Exception(se.Message);
                }
                catch (System.Exception e)
                {
                    throw new Exception(e.Message);
                }
                finally
                {
                    Connection.Close();
                }
            }
        }

        public static void EditProduto(Produto produto, HttpPostedFileBase fileBase)
        {
            var ConnectionString = DAO.CaminhoBanco();

            using (var Connection = new SqlConnection(ConnectionString))
            {
                string Imagens = Path.Combine(HttpContext.Current.Server.MapPath("~/Imagens"), fileBase.FileName);

                var CommandText = $"UPDATE Produto SET Nome = '{produto.Nome}', Estoque = '{produto.Estoque}', Preco = '{produto.Preco}' WHERE IdProduto = {produto.IdProduto}";
                var UpdateCommand = new SqlCommand(CommandText, Connection);

                try
                {
                    Connection.Open();
                    UpdateCommand.ExecuteNonQuery();
                }
                catch (SqlException se)
                {
                    throw new Exception("Erro ao tentar atualizar dados " + se.Message);
                }
                catch (System.Exception e)
                {
                    throw new Exception("Erro inesperado " + e.Message);
                }
                finally
                {
                    Connection.Close();
                }
            }
        }

        public static void DeleteProduto(int id)
        {
            var ConnectionString = DAO.CaminhoBanco();

            using (var Connection = new SqlConnection(ConnectionString))
            {
                var CommandText = $"DELETE FROM Produto WHERE IdProduto = {id}";
                var DeleteCommand = new SqlCommand(CommandText, Connection);

                try
                {
                    Connection.Open();
                    DeleteCommand.ExecuteNonQuery();
                }
                catch (SqlException se)
                {
                    throw new Exception("Erro ao tentar atualizar dados " + se.Message);
                }
                catch (System.Exception e)
                {
                    throw new Exception("Erro inesperado " + e.Message);
                }
                finally
                {
                    Connection.Close();
                }
            }
        }

        public static bool VerificarProdutoCadastradoMercado(Produto produto)
        {
            var ConnectionString = DAO.CaminhoBanco();

            bool tem = false;

            using (var Connection = new SqlConnection(ConnectionString))
            {
                var CommandText = $"SELECT * FROM Produto WHERE Nome = '{produto.Nome}' and Fabricante = '{produto.Fabricante}'";
                var SelectCommand = new SqlCommand(CommandText, Connection);

                try
                {
                    Connection.Open();

                    using (var reader = SelectCommand.ExecuteReader(CommandBehavior.CloseConnection))
                    {
                        if (reader.HasRows)
                        {
                            tem = true;
                        }
                    }
                }
                catch (SqlException se)
                {
                    throw new Exception(se.Message);
                }
                catch (System.Exception e)
                {
                    throw new Exception(e.Message);
                }
                finally
                {
                    Connection.Close();
                }
                return tem;
            }
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using SocialMarket.Models;
using SocialMarket.Utils;

namespace SocialMarket.Repository
{
    public class ListaDeCompraRepository
    {
        public static IEnumerable<Models.ListaDeCompra> GetAllItemDeCompra(Pessoa pessoa)
        {
            var ConnectionString = DAO.CaminhoBanco();

            using (var Connection = new SqlConnection(ConnectionString))
            {
                var CommandText = $"SELECT * FROM ListaDeCompra WHERE IdPessoa = {pessoa.IdPessoa}";
                var SelectCommand = new SqlCommand(CommandText, Connection);

                ListaDeCompra listaDeCompra = null;
                var listaDeCompras = new List<ListaDeCompra>();

                try
                {
                    Connection.Open();

                    using (var reader = SelectCommand.ExecuteReader(CommandBehavior.CloseConnection))
                    {
                        while (reader.Read())
                        {
                            listaDeCompra = new ListaDeCompra();

                            listaDeCompra.IdPessoa = (int)reader["IdPessoa"];
                            listaDeCompra.IdItem = (int)reader["IdItem"];
                            listaDeCompra.Descricao = reader["Descricao"].ToString();
                            listaDeCompra.Item = reader["Item"].ToString();
                            listaDeCompra.Quantidade = (int)reader["Quantidade"];
                            listaDeCompra.Data = (DateTime)reader["Data"];

                            listaDeCompras.Add(listaDeCompra);
                        }
                    }
                }
                catch (SqlException se)
                {
                    throw new Exception(se.Message);
                }
                catch (System.Exception e)
                {
                    throw new Exception(e.Message);
                }
                finally
                {
                    Connection.Close();
                }
                return listaDeCompras;
            }
        }

        public static ListaDeCompra GetItemDeCompra(int id)
        {
            var ConnectionString = DAO.CaminhoBanco();

            using (var Connection = new SqlConnection(ConnectionString))
            {
                var CommandText = $"SELECT * FROM ListaDeCompra WHERE IdItem = {id}";
                var SelectCommand = new SqlCommand(CommandText, Connection);

                ListaDeCompra listaDeCompra = null;

                try
                {
                    Connection.Open();

                    using (var reader = SelectCommand.ExecuteReader(CommandBehavior.CloseConnection))
                    {
                        while (reader.Read())
                        {
                            listaDeCompra = new ListaDeCompra();

                            listaDeCompra.IdPessoa = (int)reader["IdPessoa"];
                            listaDeCompra.IdItem = (int)reader["IdItem"];
                            listaDeCompra.Descricao = reader["Descricao"].ToString();
                            listaDeCompra.Item = reader["Item"].ToString();
                            listaDeCompra.Quantidade = (int)reader["Quantidade"];
                        }
                    } 
                }
                catch (SqlException se)
                {
                    throw new Exception(se.Message);
                }
                catch (System.Exception e)
                {
                    throw new Exception(e.Message);
                }
                finally
                {
                    Connection.Close();
                }
                return listaDeCompra;
            }
        }

        internal void CreateItemDeCompra(ListaDeCompra listaDeCompra, Pessoa pessoa)
        {
            var ConnectionString = DAO.CaminhoBanco();

            using (var Connection = new SqlConnection(ConnectionString))
            {
                var CommandText = "INSERT INTO ListaDeCompra (IdPessoa, Descricao, Item, Quantidade, Data) VALUES (@IdPessoa, @Descricao, @Item, @Quantidade, @Data)";
                var InsertCommand = new SqlCommand(CommandText, Connection);

                InsertCommand.Parameters.AddWithValue("IdPessoa", pessoa.IdPessoa);
                InsertCommand.Parameters.AddWithValue("Descricao", listaDeCompra.Descricao);
                InsertCommand.Parameters.AddWithValue("Item", listaDeCompra.Item);
                InsertCommand.Parameters.AddWithValue("Quantidade", listaDeCompra.Quantidade);
                InsertCommand.Parameters.AddWithValue("Data", DateTime.Now);
            
                try
                {
                    Connection.Open();
                    InsertCommand.ExecuteNonQuery();
                }
                catch (SqlException se)
                {
                    throw new Exception(se.Message);
                }
                catch (System.Exception e)
                {
                    throw new Exception(e.Message);
                }
                finally
                {
                    Connection.Close();
                }

                //using (var Connection2 = new SqlConnection(ConnectionString))
                //{
                //    var CommandText3 = $"SELECT MAX (IdListaDeCompra) as MAIOR FROM ListaDeCompra WHERE IdPessoa = {pessoa.IdPessoa}";
                //    var SelectCommand = new SqlCommand(CommandText3, Connection2);

                //    try
                //    {
                //        Connection2.Open();
                //        using (var reader = SelectCommand.ExecuteReader(CommandBehavior.CloseConnection))
                //        {
                //            while (reader.Read())
                //            {
                                

                //                listaDeCompra.IdListaDeCompra = (int)reader["MAIOR"];
                //            }
                //        }
                //    }
                //    catch (SqlException se)
                //    {
                //        throw new Exception(se.Message);
                //    }
                //    catch (System.Exception e)
                //    {
                //        throw new Exception(e.Message);
                //    }
                //    finally
                //    {
                //        Connection2.Close();
                //    }
                //}
            }
        }

        public static void EditItem(int id, ListaDeCompra listaDeCompra)
        {
            var ConnectionString = DAO.CaminhoBanco();

            using (var Connection = new SqlConnection(ConnectionString))
            {
                var CommandText = $"UPDATE ListaDeCompra SET Descricao = '{listaDeCompra.Descricao}', Item = '{listaDeCompra.Item}', Quantidade = '{listaDeCompra.Quantidade}' WHERE IdItem = {id}";
                var UpdateCommand = new SqlCommand(CommandText, Connection);

                try
                {
                    Connection.Open();
                    UpdateCommand.ExecuteNonQuery();
                }
                catch (SqlException se)
                {
                    throw new Exception("Erro ao tentar atualizar dados " + se.Message);
                }
                catch (System.Exception e)
                {
                    throw new Exception("Erro inesperado " + e.Message);
                }
                finally
                {
                    Connection.Close();
                }
            }
        }

        public static void DeleteItemDeCompra(int id)
        {
            var ConnectionString = DAO.CaminhoBanco();

            using (var Connection = new SqlConnection(ConnectionString))
            {
                var CommandText = $"DELETE FROM ListaDeCompra WHERE IdItem = {id}";
                var DeleteCommand = new SqlCommand(CommandText, Connection);

                try
                {
                    Connection.Open();
                    DeleteCommand.ExecuteNonQuery();
                }
                catch (SqlException se)
                {
                    throw new Exception("Erro ao tentar atualizar dados " + se.Message);
                }
                catch (System.Exception e)
                {
                    throw new Exception("Erro inesperado " + e.Message);
                }
                finally
                {
                    Connection.Close();
                }
            }
        }
    }
}
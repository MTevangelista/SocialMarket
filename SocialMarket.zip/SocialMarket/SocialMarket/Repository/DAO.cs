﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SocialMarket.Repository
{
    public class DAO
    {
        public static string CaminhoBanco()
        {
            string ConnectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\mathe\Documents\SocialMarket\SocialMarket\App_Data\SocialDB.mdf;Integrated Security=True";

            return ConnectionString;
        }
    }
}
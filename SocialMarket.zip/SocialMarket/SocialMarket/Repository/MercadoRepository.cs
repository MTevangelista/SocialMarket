﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using SocialMarket.Utils;
using System.Linq;
using SocialMarket.Repository;
using System.Web;
using SocialMarket.Models;

namespace SocialMarket.Repository
{
    public class MercadoRepository
    {
        public static IEnumerable<Models.Mercado> GetAllMercado(Mercado mercado)
        {
            var ConnectionString = DAO.CaminhoBanco();

            using (var Connection = new SqlConnection(ConnectionString))
            {
                var CommandText = $"SELECT * FROM Mercado WHERE IdMercado = {mercado.IdMercado}";
                var SelectCommand = new SqlCommand(CommandText, Connection);

                //Models.Mercado mercado = null;
                var mercados = new List<Models.Mercado>();

                try
                {
                    Connection.Open();

                    using (var reader = SelectCommand.ExecuteReader(CommandBehavior.CloseConnection))
                    {
                        while (reader.Read())
                        {
                            mercado = new Models.Mercado();

                            mercado.IdMercado = (int)reader["IdMercado"];
                            mercado.Nome = reader["Nome"].ToString();
                            mercado.NomeUsuario = reader["NomeUsuario"].ToString();
                            mercado.Email = reader["Email"].ToString();
                            mercado.Senha = reader["Senha"].ToString();
                            mercado.Telefone = reader["Telefone"].ToString();
                            mercado.CNPJ = reader["CNPJ"].ToString();
                            mercado.CEP = reader["CEP"].ToString();

                            mercados.Add(mercado);
                        }
                    }
                }
                catch (SqlException se)
                {
                    throw new Exception(se.Message);
                }
                catch (System.Exception e)
                {
                    throw new Exception(e.Message);
                }
                finally
                {
                    Connection.Close();
                }
                return mercados;
            }
        }

        public static Mercado GetMercado(int id)
        {
            var ConnectionString = DAO.CaminhoBanco();

            using (var Connection = new SqlConnection(ConnectionString))
            {
                var CommandText = $"SELECT * FROM Mercado WHERE IdMercado = {id}";
                var SelectCommand = new SqlCommand(CommandText, Connection);

                Models.Mercado mercado = null;

                try
                {
                    Connection.Open();

                    using (var reader = SelectCommand.ExecuteReader(CommandBehavior.CloseConnection))
                    {
                        while (reader.Read())
                        {
                            mercado = new Models.Mercado();

                            mercado.IdMercado = (int)reader["IdMercado"];
                            mercado.Nome = reader["Nome"].ToString();
                            mercado.NomeUsuario = reader["NomeUsuario"].ToString();
                            mercado.Email = reader["Email"].ToString();
                            mercado.Senha = reader["Senha"].ToString();
                            mercado.Telefone = reader["Telefone"].ToString();
                            mercado.CNPJ = reader["CNPJ"].ToString();
                            mercado.CEP = reader["CEP"].ToString();
                        }
                    }
                }
                catch (SqlException se)
                {
                    throw new Exception("Erro ao tentar atualizar dados " + se.Message);
                }
                catch (System.Exception e)
                {
                    throw new Exception("Erro inesperado " + e.Message);
                }
                finally
                {
                    Connection.Close();
                }
                return mercado;
            }
        }

        internal void CreateMercado(Models.Mercado mercado)
        {
            var ConnectionString = DAO.CaminhoBanco();

            using (var Connection = new SqlConnection(ConnectionString))
            {
                var CommandText = "INSERT INTO Mercado (Nome, NomeUsuario, Email, Senha, Telefone, CNPJ, CEP) VALUES (@Nome, @NomeUsuario, @Email, @Senha, @Telefone, @CNPJ, @CEP)";
                var InsertCommand = new SqlCommand(CommandText, Connection);
                InsertCommand.Parameters.AddWithValue("Nome", mercado.Nome);
                InsertCommand.Parameters.AddWithValue("NomeUsuario", mercado.NomeUsuario);
                InsertCommand.Parameters.AddWithValue("Email", mercado.Email);
                InsertCommand.Parameters.AddWithValue("Senha", mercado.Senha);
                InsertCommand.Parameters.AddWithValue("Telefone", mercado.Telefone);
                InsertCommand.Parameters.AddWithValue("CNPJ", mercado.CNPJ);
                InsertCommand.Parameters.AddWithValue("CEP", mercado.CEP);

                try
                {
                    Connection.Open();
                    InsertCommand.ExecuteNonQuery();
                }
                catch (SqlException se)
                {
                    throw new Exception("Erro ao tentar atualizar dados " + se.Message);
                }
                catch (System.Exception e)
                {
                    throw new Exception("Erro inesperado " + e.Message);
                }
                finally
                {
                    Connection.Close();
                }
            }
        }

        public static void EditMercado(Models.Mercado mercado)
        {
            var ConnectionString = DAO.CaminhoBanco();

            using (var Connection = new SqlConnection(ConnectionString))
            {
                var CommandText = $"UPDATE Mercado SET Nome = '{mercado.Nome}', NomeUsuario = '{mercado.NomeUsuario}', Email = '{mercado.Email}', Senha = '{mercado.Senha}', Telefone = '{mercado.Telefone}', CNPJ = '{mercado.CNPJ}', CEP = '{mercado.CEP}' WHERE IdMercado = {mercado.IdMercado}";
                var UpdateCommand = new SqlCommand(CommandText, Connection);

                try
                {
                    Connection.Open();
                    UpdateCommand.ExecuteNonQuery();
                }
                catch (SqlException se)
                {
                    throw new Exception("Erro ao tentar atualizar dados " + se.Message);
                }
                catch (System.Exception e)
                {
                    throw new Exception("Erro inesperado " + e.Message);
                }
                finally
                {
                    Connection.Close();
                }
            }
        }

        public static void DeleteMercado(int id)
        {
            var ConnectionString = DAO.CaminhoBanco();

            using (var Connection = new SqlConnection(ConnectionString))
            {
                var CommandText = $"DELETE FROM Mercado WHERE IdMercado = {id}";
                var DeleteCommand = new SqlCommand(CommandText, Connection);

                try
                {
                    Connection.Open();
                    DeleteCommand.ExecuteNonQuery();
                }
                catch (SqlException se)
                {
                    throw new Exception("Erro ao tentar atualizar dados " + se.Message);
                }
                catch (System.Exception e)
                {
                    throw new Exception("Erro inesperado " + e.Message);
                }
                finally
                {
                    Connection.Close();
                }
            }
        }

        #region Verificar Cadastro Existente Mercado
        public static bool VerificarCadastroExistenteMercadoEmail(Models.Mercado mercado)
        {
            var ConnectionString = DAO.CaminhoBanco();
            bool email = false;

            using (var Connection = new SqlConnection(ConnectionString))
            {
                var CommandText = $"SELECT * FROM Mercado WHERE Email = '{mercado.Email}'";
                var SelectCommand = new SqlCommand(CommandText, Connection);

                try
                {
                    Connection.Open();

                    using (var reader = SelectCommand.ExecuteReader(CommandBehavior.CloseConnection))
                    {
                        if (reader.HasRows)
                        {
                            email = true;
                        }
                    }
                }
                catch (SqlException se)
                {
                    throw new Exception("Erro ao tentar atualizar dados " + se.Message);
                }
                catch (System.Exception e)
                {
                    throw new Exception("Erro inesperado " + e.Message);
                }
                finally
                {
                    Connection.Close();
                }
                return email;
            }
        }

        public static bool VerificarCadastroExistenteMercadoNomeUsuario(Models.Mercado mercado)
        {
            var ConnectionString = DAO.CaminhoBanco();
            bool nomeUsuario = false;

            using (var Connection = new SqlConnection(ConnectionString))
            {
                var CommandText = $"SELECT * FROM Mercado WHERE NomeUsuario = '{mercado.NomeUsuario}'";
                var SelectCommand = new SqlCommand(CommandText, Connection);

                try
                {
                    Connection.Open();

                    using (var reader = SelectCommand.ExecuteReader(CommandBehavior.CloseConnection))
                    {
                        if (reader.HasRows)
                        {
                            nomeUsuario = true;
                        }
                    }
                }
                catch (SqlException se)
                {
                    throw new Exception("Erro ao tentar atualizar dados " + se.Message);
                }
                catch (System.Exception e)
                {
                    throw new Exception("Erro inesperado " + e.Message);
                }
                finally
                {
                    Connection.Close();
                }
                return nomeUsuario;
            }
        }

        public static bool VerificarCadastroExistenteMercadoTelefone(Models.Mercado mercado)
        {
            var ConnectionString = DAO.CaminhoBanco();
            bool telefone = false;

            using (var Connection = new SqlConnection(ConnectionString))
            {
                var CommandText = $"SELECT * FROM Mercado WHERE Telefone = '{mercado.Telefone}'";
                var SelectCommand = new SqlCommand(CommandText, Connection);

                try
                {
                    Connection.Open();

                    using (var reader = SelectCommand.ExecuteReader(CommandBehavior.CloseConnection))
                    {
                        if (reader.HasRows)
                        {
                            telefone = true;
                        }
                    }
                }
                catch (SqlException se)
                {
                    throw new Exception("Erro ao tentar atualizar dados " + se.Message);
                }
                catch (System.Exception e)
                {
                    throw new Exception("Erro inesperado " + e.Message);
                }
                finally
                {
                    Connection.Close();
                }
                return telefone;
            }
        }

        public static bool VerificarCadastroExistenteMercadoCNPJ(Models.Mercado mercado)
        {
            var ConnectionString = DAO.CaminhoBanco();
            bool cnpj = false;

            using (var Connection = new SqlConnection(ConnectionString))
            {
                var CommandText = $"SELECT * FROM Mercado WHERE CNPJ = '{mercado.CNPJ}'";
                var SelectCommand = new SqlCommand(CommandText, Connection);

                try
                {
                    Connection.Open();

                    using (var reader = SelectCommand.ExecuteReader(CommandBehavior.CloseConnection))
                    {
                        if (reader.HasRows)
                        {
                            cnpj = true;
                        }
                    }
                }
                catch (SqlException se)
                {
                    throw new Exception("Erro ao tentar atualizar dados " + se.Message);
                }
                catch (System.Exception e)
                {
                    throw new Exception("Erro inesperado " + e.Message);
                }
                finally
                {
                    Connection.Close();
                }
                return cnpj;
            }
        }
      
        #endregion

        public  Models.Mercado VerificarLoginMercado(Models.Mercado mercado)
        {
            var ConnectionString = DAO.CaminhoBanco();

            using (var Connection = new SqlConnection(ConnectionString))
            {
                var CommandText = $"SELECT * FROM Mercado WHERE NomeUsuario = '{mercado.NomeUsuario}'";
                var SelectCommand = new SqlCommand(CommandText, Connection);

                try
                {
                    Connection.Open();

                    using (var reader = SelectCommand.ExecuteReader(CommandBehavior.CloseConnection))
                    {
                        if (reader.HasRows)
                        {
                            reader.Read();
                            if (Hash.GerarHash(mercado.Senha) == reader["Senha"].ToString())
                            {
                                mercado.IdMercado = (int)reader["IdMercado"];
                                mercado.Nome = reader["Nome"].ToString();
                                mercado.NomeUsuario = reader["NomeUsuario"].ToString();
                                mercado.Email = reader["Email"].ToString();
                                mercado.Senha = reader["Senha"].ToString();
                                mercado.Telefone = reader["Telefone"].ToString();
                                mercado.CNPJ = reader["CNPJ"].ToString();
                                mercado.CEP = reader["CEP"].ToString();
                            }
                            else
                            {
                                mercado = null;
                            }
                        }
                        else
                        {
                            mercado = null;
                        }
                    }
                }
                catch (SqlException se)
                {
                    throw new Exception(se.Message);
                }
                catch (System.Exception e)
                {
                    throw new Exception(e.Message);
                }
                finally
                {
                    Connection.Close();
                }
                return mercado;
            }
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using SocialMarket.Models;
using SocialMarket.Utils;
using System.IO;

namespace SocialMarket.Repository
{
    public class ComentarioRepository
    {
        public static IEnumerable<Models.Comentario> GetAllComentario(int id)
        {
            var ConnectionString = DAO.CaminhoBanco();

            using (var Connection = new SqlConnection(ConnectionString))
            {
                var CommandText = $"SELECT * FROM Comentario, Pessoa WHERE IdPostagem = {id} AND Comentario.IdPessoa = Pessoa.IdPessoa";
                var SelectCommand = new SqlCommand(CommandText, Connection);

                Comentario comentario = null;
                var comentarios = new List<Comentario>();

                try
                {
                    Connection.Open();

                    using (var reader = SelectCommand.ExecuteReader(CommandBehavior.CloseConnection))
                    {
                        while (reader.Read())
                        {
                            comentario = new Comentario();

                            comentario.IdComentario = (int)reader["IdComentario"];
                            comentario.IdPostagem = (int)reader["IdPostagem"];
                            comentario.IdPessoa = (int)reader["IdPessoa"];
                            comentario.NomeUsuario = reader["NomeUsuario"].ToString();
                            comentario.Conteudo = reader["Conteudo"].ToString();
                            comentario.Data = (DateTime)reader["Data"];

                            comentarios.Add(comentario);
                        }
                    }
                }
                catch (SqlException se)
                {
                    throw new Exception(se.Message);
                }
                catch (System.Exception e)
                {
                    throw new Exception(e.Message);
                }
                finally
                {
                    Connection.Close();
                }
                return comentarios;
            }
        }

        internal void CreateComentario(int id, Comentario comentario, Pessoa pessoa)
        {
            var ConnectionString = DAO.CaminhoBanco();

            using (var Connection = new SqlConnection(ConnectionString)) 
            {
                var CommandText = "INSERT INTO Comentario(IdPostagem, IdPessoa, Conteudo, Data) VALUES (@IdPostagem, @IdPessoa, @Conteudo, @Data)";
                var InsertCommand = new SqlCommand(CommandText, Connection);
                
                InsertCommand.Parameters.AddWithValue("IdPostagem", id);
                InsertCommand.Parameters.AddWithValue("IdPessoa", pessoa.IdPessoa);
                InsertCommand.Parameters.AddWithValue("Conteudo", comentario.Conteudo);
                InsertCommand.Parameters.AddWithValue("Data", DateTime.Now);

                try
                {
                    Connection.Open();
                    InsertCommand.ExecuteNonQuery();
                }
                catch (SqlException se)
                {
                    throw new Exception(se.Message);
                }
                catch (System.Exception e)
                {
                    throw new Exception(e.Message);
                }
                finally
                {
                    Connection.Close();
                }
            }
        }

        public static void DeleteComentario(int id, Pessoa pessoa)
        {
            var ConnectionString = DAO.CaminhoBanco();

            using (var Connection = new SqlConnection(ConnectionString))
            {
                var CommandText = $"DELETE FROM Comentario WHERE IdComentario = {id} AND Comentario.IdPessoa = {pessoa.IdPessoa}";
                var DeleteCommand = new SqlCommand(CommandText, Connection);

                try
                {
                    Connection.Open();
                    DeleteCommand.ExecuteNonQuery();
                }
                catch (SqlException se)
                {
                    throw new Exception(se.Message);
                }
                catch (System.Exception e)
                {
                    throw new Exception(e.Message);
                }
                finally
                {
                    Connection.Close();
                }
            }
        }

        public static Postagem GetPostagem(int id)
        {
            var ConnectionString = DAO.CaminhoBanco();

            using (var Connection = new SqlConnection(ConnectionString))
            {
                var CommandText = $"SELECT * FROM Postagem WHERE IdPostagem = {id}";
                var SelectCommand = new SqlCommand(CommandText, Connection);

                Models.Postagem postagem = null;

                try
                {
                    Connection.Open();

                    using (var reader = SelectCommand.ExecuteReader(CommandBehavior.CloseConnection))
                    {
                        while (reader.Read())
                        {
                            postagem = new Postagem();

                            postagem.IdPostagem = (int)reader["IdPostagem"];
                            postagem.IdPessoa = (int)reader["IdPostagem"];
                            postagem.Conteudo = reader["Conteudo"].ToString();
                            postagem.Midia = reader["Midia"].ToString();
                        }
                    }
                }
                catch (SqlException se)
                {
                    throw new Exception(se.Message);
                }
                catch (System.Exception e)
                {
                    throw new Exception(e.Message);
                }
                finally
                {
                    Connection.Close();
                }
                return postagem;
            }
        }
    }
}
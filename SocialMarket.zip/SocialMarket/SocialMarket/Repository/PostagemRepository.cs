﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using SocialMarket.Models;
using System.IO;
using SocialMarket.Utils;

namespace SocialMarket.Repository
{
    public class PostagemRepository
    {
        public static IEnumerable<Postagem> GetAllPostagem(Pessoa pessoa)
        {
            var ConnectionString = DAO.CaminhoBanco();

            using (var Connection = new SqlConnection(ConnectionString))
            {
                
                var CommandText = $"SELECT * FROM Postagem WHERE IdPessoa = {pessoa.IdPessoa}";
                var SelectCommand = new SqlCommand(CommandText, Connection);

                Postagem postagem = null;
                var postagens = new List<Postagem>();

                try
                {
                    Connection.Open();

                    using (var reader = SelectCommand.ExecuteReader(CommandBehavior.CloseConnection))
                    {
                        while (reader.Read())
                        {
                            postagem = new Postagem();

                            postagem.IdPostagem = (int)reader["IdPostagem"];
                            postagem.IdPessoa = (int)reader["IdPessoa"];
                            postagem.Conteudo = reader["Conteudo"].ToString();
                            postagem.Midia = reader["Midia"].ToString();
                            postagem.Data = (DateTime)reader["Data"];
                            postagens.Add(postagem);
                        }
                    }
                }
                catch (SqlException se)
                {
                    throw new Exception(se.Message);
                }
                catch (System.Exception e)
                {
                    throw new Exception(e.Message);
                }
                finally
                {
                    Connection.Close();
                }
                return postagens;
            }
        }

        public static IEnumerable<Postagem> Feed(Pessoa pessoa, Compartilhamento compartilhamento)
        {
            var ConnectionString = DAO.CaminhoBanco();

            //SELECT PARA PEGAR AS POSTAGENS DOS MEUS AMIGOS
            using (var Connection = new SqlConnection(ConnectionString))
            {
                // Primeiro, vou na tabaela de Amizade e pego todos os amigos onde eu sou o IdPessoaDestino;
                // Segundo, vou na tabela de Postagem e pego todas as postagens dos meus amigos, ou seja, onde o IdPessoa seja igual a IdPessoaOrigem(quem me solicitou amizade);
                // Terceiro, vou na tabela de Pessoa e pego o nome da pessoa cujo IdPessoa seja igual ao IdPessoa na tabela de Postagem;
                var CommandText = $"SELECT IdPostagem, NomeUsuario, Conteudo, Midia, postagem.Data FROM Postagem, Pessoa, Amizade WHERE IdPessoaDestino = {pessoa.IdPessoa} AND Postagem.IdPessoa = Amizade.IdPessoaOrigem AND pessoa.IdPessoa = Postagem.IdPessoa AND Aceito = 1";
                var SelectCommand = new SqlCommand(CommandText, Connection);

                Models.Postagem postagem = null;
                var postagens = new List<Models.Postagem>();

                try
                {
                    Connection.Open();

                    using (var reader = SelectCommand.ExecuteReader(CommandBehavior.CloseConnection))
                    {
                        while (reader.Read())
                        {
                            postagem = new Models.Postagem();
                            using (var ConnectionCurtida = new SqlConnection(ConnectionString))
                            {
                                var CommandTextCurtida = $"SELECT * FROM CurtidaPost WHERE CurtidaPost.IdPostagem = {(int)reader["IdPostagem"]} ";
                                var SelectCommandCurtida = new SqlCommand(CommandTextCurtida, ConnectionCurtida);

                                ConnectionCurtida.Open();
                                // contar as curtidas da postagem que está sendo lida, para mostrar a quatidade de curtidas na view
                                using (var reader2 = SelectCommandCurtida.ExecuteReader(CommandBehavior.CloseConnection))
                                {
                                    while (reader2.Read())
                                    {
                                       //tirei daqui
                                        postagem.QuantidadeCurtida = postagem.QuantidadeCurtida + 1;
                                    }
                                }

                                ConnectionCurtida.Close();

                                //coloquei aqui
                                //verificar se o usuário da session já curtiu a postagem que está sendo lida, usado para testar se o botão fica azul ou default
                                using (var ConnectionMinhaCurtida = new SqlConnection(ConnectionString))
                                {
                                    var CommandTextMinhaCurtida = $"SELECT * FROM CurtidaPost WHERE CurtidaPost.IdPostagem = {(int)reader["IdPostagem"]} AND CurtidaPost.IdPessoaCurtiu = {pessoa.IdPessoa}";
                                    var SelectCommandMinhaCurtida = new SqlCommand(CommandTextMinhaCurtida, ConnectionMinhaCurtida);

                                    ConnectionMinhaCurtida.Open();

                                    using (var readerMinhaCurtida = SelectCommandMinhaCurtida.ExecuteReader(CommandBehavior.CloseConnection))
                                    {
                                        while (readerMinhaCurtida.Read())
                                        {
                                            postagem.MinhaCurtida = "sim";
                                        }
                                    }
                                    ConnectionMinhaCurtida.Close();
                                }
                                //

                            }
                            postagem.IdPostagem = (int)reader["IdPostagem"];
                            postagem.NomeUsuario = reader["NomeUsuario"].ToString();
                            postagem.Conteudo = reader["Conteudo"].ToString();
                            postagem.Midia = reader["Midia"].ToString();
                            postagem.Data = (DateTime)reader["Data"];

                            postagens.Add(postagem);
                        }
                    }
                }
                catch (SqlException se)
                {
                    throw new Exception(se.Message);
                }
                catch (System.Exception e)
                {
                    throw new Exception(e.Message);
                }
                finally
                {
                    Connection.Close();
                }

                //SELECT PARA PEGAR AS MINHAS POSTAGENS E REPOSTAGENS
                using (var Connection2 = new SqlConnection(ConnectionString))
                {
                    var CommandText2 = $"SELECT Compartilhamento.IdPostagemPostou AS IdPostagemPostou, Compartilhamento.IdPessoaRepostou AS IdPessoaRepostou, Compartilhamento.DataComp AS DataComp, Postagem.IdPessoa, Postagem.IdPostagem, Postagem.Conteudo, Postagem.Midia, Postagem.Data, Pessoa.NomeUsuario AS NomeUsuarioPostou FROM Compartilhamento,Pessoa,Postagem WHERE Compartilhamento.IdPessoaRepostou = {pessoa.IdPessoa} AND Compartilhamento.IdPostagemPostou = Postagem.IdPostagem AND Postagem.IdPessoa = Pessoa.IdPessoa UNION " +
                                       $"SELECT 0 AS IdPostagemPostou, 0 AS IdPessoaRepostou, null AS DataComp, Postagem.IdPessoa,Postagem.IdPostagem, Postagem.Conteudo,Postagem.Midia, Postagem.Data, Pessoa.NomeUsuario AS NomeUsuarioPostou FROM Pessoa, Postagem WHERE Pessoa.IdPessoa = {pessoa.IdPessoa} AND Pessoa.IdPessoa = Postagem.IdPessoa";
                    var SelectCommand2 = new SqlCommand(CommandText2, Connection2);

                    try
                    {
                        Connection2.Open();

                        using (var reader = SelectCommand2.ExecuteReader(CommandBehavior.CloseConnection))
                        {
                            while (reader.Read())
                            {
                                postagem = new Models.Postagem();

                                postagem.IdPostagem = (int)reader["IdPostagem"];

                                
                                if ((int)reader["IdPostagemPostou"] == 0)
                                {
                                    //Joga null no usuário que repostou, pois não é um compartilhamento (usado para testar na view se é Compartilhamento ou Postagem)
                                    postagem.NomeUsuarioRepostou = null;

                                    //verificar se o usuário da session já curtiu a postagem que está sendo lida, usado para testar se o botão fica azul ou default
                                    using (var ConnectionCurtida = new SqlConnection(ConnectionString))
                                    {
                                        var CommandTextCurtida = $"SELECT * FROM CurtidaPost WHERE CurtidaPost.IdPostagem = {(int)reader["IdPostagem"]} AND CurtidaPost.IdPessoaCurtiu = {pessoa.IdPessoa}";
                                        var SelectCommandCurtida = new SqlCommand(CommandTextCurtida, ConnectionCurtida);

                                        ConnectionCurtida.Open();

                                        using (var reader2 = SelectCommandCurtida.ExecuteReader(CommandBehavior.CloseConnection))
                                        {
                                            while (reader2.Read())
                                            {
                                                postagem.MinhaCurtida = "sim";
                                                
                                            }

                                        }
                                        ConnectionCurtida.Close();
                                    }
                                    // contar as curtidas da postagem que está sendo lida, para mostrar a quatidade de curtidas na view
                                    using (var ConnectionmCurtida = new SqlConnection(ConnectionString))
                                    {
                                       var CommandTextmCurtida = $"SELECT * FROM CurtidaPost WHERE CurtidaPost.IdPostagem = {(int)reader["IdPostagem"]} ";
                                       var SelectCommandmCurtida = new SqlCommand(CommandTextmCurtida, ConnectionmCurtida);

                                       ConnectionmCurtida.Open();

                                       using (var readermcurtida = SelectCommandmCurtida.ExecuteReader(CommandBehavior.CloseConnection))
                                       {
                                          while (readermcurtida.Read())
                                          {
                                             postagem.QuantidadeCurtida = postagem.QuantidadeCurtida + 1;
                                          }

                                       }
                                         ConnectionmCurtida.Close();

                                    }
                                    
                                }
                                //Se for Compartilhamento de Postagem, entra no Else para pegar o nome de quem repostou e a data
                                else
                                {
                                    using (var ConnectionComp = new SqlConnection(ConnectionString))
                                    {
                                        var CommandTextComp = $"SELECT * FROM CurtidaComp WHERE CurtidaComp.IdPostagem = {(int)reader["IdPostagem"]} ";
                                        var SelectCommandComp = new SqlCommand(CommandTextComp, ConnectionComp);

                                        ConnectionComp.Open();

                                        using (var readerComp = SelectCommandComp.ExecuteReader(CommandBehavior.CloseConnection))
                                        {
                                            while (readerComp.Read())
                                            {
                                                postagem.QuantidadeCurtida = postagem.QuantidadeCurtida + 1;
                                            }
                                        }
                                        ConnectionComp.Close();
                                    }
                                    postagem.NomeUsuarioRepostou = pessoa.NomeUsuario;
                                    postagem.DataComp = (DateTime)reader["DataComp"];
                                }

                                postagem.NomeUsuario = reader["NomeUsuarioPostou"].ToString();
                                postagem.Conteudo = reader["Conteudo"].ToString();
                                postagem.Midia = reader["Midia"].ToString();
                                postagem.Data = (DateTime)reader["Data"];

                                postagens.Add(postagem);
                            }
                        }
                    }
                    catch (SqlException se)
                    {
                        throw new Exception(se.Message);
                    }
                    catch (System.Exception e)
                    {
                        throw new Exception(e.Message);
                    }
                    finally
                    {
                        Connection2.Close();
                    }
                    
                }

                //SELECT PARA PEGAR AS REPOSTAGENS DOS MEUS AMIGOS(Compartilhamento)
                using (var Connection3 = new SqlConnection(ConnectionString))
                {
                    // Primeiro, vou na tabela de Amizade e pego todos os amigos onde eu sou o IdPessoaDestino;
                    // Segundo, vou na tabela de Compartilhamento e pego todos postagens compartilhadas dos meus amigos, ou seja, onde o IdPessoa seja igual a IdPessoaPostou;
                    // Terceiro, vou na tabela de Pessoa e pego o nome da pessoa cujo IdPessoa seja igual ao IdPessoa na tabela de Postagem;
                    var CommandText3 = $"SELECT Compartilhamento.IdPessoaRepostou, Compartilhamento.DataComp, Pessoa1.NomeUsuario AS NomeUsuarioRepostou,Postagem.IdPostagem, Pessoa2.NomeUsuario AS NomeUsuarioPostou,Conteudo, Midia, postagem.Data FROM Compartilhamento, Postagem, Pessoa AS Pessoa1, Pessoa AS Pessoa2 WHERE Compartilhamento.IdPostagemPostou = Postagem.IdPostagem  AND Compartilhamento.IdPessoaRepostou = Pessoa1.IdPessoa AND Postagem.IdPessoa = Pessoa2.IdPessoa";
                    var SelectCommand3 = new SqlCommand(CommandText3, Connection3);

                    try
                    {
                        Connection3.Open();

                        using (var reader = SelectCommand3.ExecuteReader(CommandBehavior.CloseConnection))
                        {
                            while (reader.Read())
                            {
                                using (var Connection4 = new SqlConnection(ConnectionString))
                                {
                                    var VerificaCommandText = $"SELECT * FROM Amizade Where Amizade.IdPessoaOrigem = {(int)reader["IdPessoaRepostou"]} AND Amizade.IdPessoaDestino = {pessoa.IdPessoa} AND Aceito = 1";
                                    var VerificaSelectCommand = new SqlCommand(VerificaCommandText, Connection4);

                                    Connection4.Open();

                                    using (var reader2 = VerificaSelectCommand.ExecuteReader(CommandBehavior.CloseConnection))
                                    {
                                        if (reader2.HasRows)
                                        {
                                            postagem = new Models.Postagem();

                                            using (var ConnectionComp = new SqlConnection(ConnectionString))
                                            {
                                                var CommandTextComp = $"SELECT * FROM CurtidaComp WHERE CurtidaComp.IdPostagem = {(int)reader["IdPostagem"]} ";
                                                var SelectCommandComp = new SqlCommand(CommandTextComp, ConnectionComp);

                                                ConnectionComp.Open();

                                                using (var readerComp = SelectCommandComp.ExecuteReader(CommandBehavior.CloseConnection))
                                                {
                                                    while (readerComp.Read())
                                                    {
                                                        postagem.QuantidadeCurtida = postagem.QuantidadeCurtida + 1;
                                                    }
                                                }
                                                ConnectionComp.Close();
                                            }

                                            compartilhamento.IdPessoaRepostou = (int)reader["IdPessoaRepostou"];
                                            postagem.IdPostagem = (int)reader["IdPostagem"];
                                            postagem.NomeUsuarioRepostou = reader["NomeUsuarioRepostou"].ToString();
                                            postagem.NomeUsuario = reader["NomeUsuarioPostou"].ToString();
                                            postagem.Conteudo = reader["Conteudo"].ToString();
                                            postagem.Midia = reader["Midia"].ToString();
                                            postagem.Data = (DateTime)reader["Data"];
                                            postagem.DataComp = (DateTime)reader["DataComp"];

                                            postagens.Add(postagem);
                                        }

                                    }
                                    Connection4.Close();
                                }
                            }
                        }
                    }
                    catch (SqlException se)
                    {
                        throw new Exception(se.Message);
                    }
                    catch (System.Exception e)
                    {
                        throw new Exception(e.Message);
                    }
                    finally
                    {
                        Connection3.Close();
                    }
                    return postagens;
                }
            }
        }

        public static Postagem GetPostagem(int id)
        {
            var ConnectionString = DAO.CaminhoBanco();

            using (var Connection = new SqlConnection(ConnectionString))
            {
                var CommandText = $"SELECT * FROM Postagem WHERE IdPostagem = {id}";
                var SelectCommand = new SqlCommand(CommandText, Connection);

                Models.Postagem postagem = null;

                try
                {
                    Connection.Open();

                    using (var reader = SelectCommand.ExecuteReader(CommandBehavior.CloseConnection))
                    {
                        while (reader.Read())
                        {
                            postagem = new Postagem();

                            postagem.IdPostagem = (int)reader["IdPostagem"];
                            postagem.IdPessoa = (int)reader["IdPostagem"];
                            postagem.Conteudo = reader["Conteudo"].ToString();
                            postagem.Midia = reader["Midia"].ToString();
                            postagem.Data = (DateTime)reader["Data"];
                        }
                    }
                }
                catch (SqlException se)
                {
                    throw new Exception(se.Message);
                }
                catch (System.Exception e)
                {
                    throw new Exception(e.Message);
                }
                finally
                {
                    Connection.Close();
                }
                return postagem;
            }
        }

        internal void CreatePostagem(Postagem postagem, HttpPostedFileBase fileBase, Pessoa pessoa)
        {
            var ConnectionString = DAO.CaminhoBanco();

            using (var Connection = new SqlConnection(ConnectionString))
            {
                var CommandText = "INSERT INTO Postagem(IdPessoa, Conteudo, Midia, Data) VALUES (@IdPessoa, @Conteudo, @Midia, @Data)";
                var InsertCommand = new SqlCommand(CommandText, Connection);

                InsertCommand.Parameters.AddWithValue("IdPessoa", pessoa.IdPessoa);
                InsertCommand.Parameters.AddWithValue("Conteudo", postagem.Conteudo);

                if (fileBase != null)
                {
                    string imagens = Path.Combine(HttpContext.Current.Server.MapPath("~/Imagens"), fileBase.FileName);
                    fileBase.SaveAs(imagens);
                    InsertCommand.Parameters.AddWithValue("Midia", fileBase.FileName);
                }
                else
                {
                    InsertCommand.Parameters.AddWithValue("Midia", "");
                }
               
                InsertCommand.Parameters.AddWithValue("Data", DateTime.Now);

                try
                {
                    Connection.Open();
                    InsertCommand.ExecuteNonQuery();
                }
                catch (SqlException se)
                {
                    throw new Exception(se.Message);
                }
                catch (System.Exception e)
                {
                    throw new Exception(e.Message);
                }
                finally
                {
                    Connection.Close();
                }
            }
        }
         
        public static void EditPostagem(Postagem postagem, HttpPostedFileBase fileBase)
        {
            var ConnectionString = DAO.CaminhoBanco();

            using (var Connection = new SqlConnection(ConnectionString))
            {
                string Imagens = Path.Combine(HttpContext.Current.Server.MapPath("~/Imagens"), fileBase.FileName);

                var CommandText = $"UPDATE Postagem SET Conteudo = '{postagem.Conteudo}', Midia = '{fileBase.FileName}' WHERE IdPostagem = {postagem.IdPostagem}";
                var UpdateCommand = new SqlCommand(CommandText, Connection);

                try
                {
                    Connection.Open();
                    UpdateCommand.ExecuteNonQuery();
                }
                catch (SqlException se)
                {
                    throw new Exception("Erro ao tentar atualizar dados " + se.Message);
                }
                catch (System.Exception e)
                {
                    throw new Exception("Erro inesperado " + e.Message);
                }
                finally
                {
                    Connection.Close();
                }
            }
        }

        public static void DeletePostagem(int id)
        {
            var ConnectionString = DAO.CaminhoBanco();

            using (var Connection = new SqlConnection(ConnectionString))
            {
                var CommandText = $"DELETE FROM Postagem WHERE IdPostagem = {id}";
                var DeleteCommand = new SqlCommand(CommandText, Connection);

                try
                {
                    Connection.Open();
                    DeleteCommand.ExecuteNonQuery();
                }
                catch (SqlException se)
                {
                    throw new Exception("Erro ao tentar atualizar dados " + se.Message);
                }
                catch (System.Exception e)
                {
                    throw new Exception("Erro inesperado " + e.Message);
                }
                finally
                {
                    Connection.Close();
                }
            }
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using SocialMarket.Models;

namespace SocialMarket.Repository
{
    public class AmizadeRepository
    {
        public static IEnumerable<Amizade> VisualizarPedidoAmizade(Amizade amizade, Pessoa pessoa)
        {
            var ConnectionString = DAO.CaminhoBanco();

            using (var Connection = new SqlConnection(ConnectionString))
            {
                var CommandText = $"SELECT * FROM Amizade, Pessoa WHERE IdPessoaDestino = {pessoa.IdPessoa} AND IdPessoaOrigem = pessoa.IdPessoa AND Aceito != 1";
                var SelectCommand = new SqlCommand(CommandText, Connection);

                var amizades = new List<Amizade>();

                try
                {
                    Connection.Open();

                    using (var reader = SelectCommand.ExecuteReader(CommandBehavior.CloseConnection))
                    {
                        while (reader.Read())
                        {
                            amizade = new Models.Amizade();

                            amizade.IdPessoaOrigem = (int)reader["IdPessoaOrigem"];
                            amizade.Aceito = (bool)reader["Aceito"];
                            amizade.NomeUsuario = reader["NomeUsuario"].ToString();
                            amizade.Data = (DateTime)reader["Data"];

                            amizades.Add(amizade);
                        }
                    }
                }
                catch (SqlException se)
                {
                    throw new Exception(se.Message);
                }
                catch (System.Exception e)
                {
                    throw new Exception(e.Message);
                }
                finally
                {
                    Connection.Close();
                }
                return amizades;
            }
        }

        public static IEnumerable<Models.Pessoa> ListarPessoa(Pessoa pessoa)
        {
            var ConnectionString = DAO.CaminhoBanco();

            using (var Connection = new SqlConnection(ConnectionString))
            {
                var CommandText = $"SELECT * FROM Pessoa WHERE IdPessoa != {pessoa.IdPessoa}";
                var SelectCommand = new SqlCommand(CommandText, Connection);

                //Models.Pessoa pessoa = null;
                var pessoas = new List<Models.Pessoa>();

                try
                {
                    Connection.Open();

                    using (var reader = SelectCommand.ExecuteReader(CommandBehavior.CloseConnection))
                    {
                        while (reader.Read())
                        {
                            pessoa = new Models.Pessoa();

                            pessoa.IdPessoa = (int)reader["IdPessoa"];
                            pessoa.NomeUsuario = reader["NomeUsuario"].ToString();
                            pessoa.Email = reader["Email"].ToString();

                            pessoas.Add(pessoa);
                        }
                    }
                }
                catch (SqlException se)
                {
                    throw new Exception(se.Message);
                }
                catch (System.Exception e)
                {
                    throw new Exception(e.Message);
                }
                finally
                {
                    Connection.Close();
                }
                return pessoas;
            }
        }

        public static IEnumerable<Amizade> ListarAmigo(Amizade amigo, Pessoa pessoa)
        {
            var ConnectionString = DAO.CaminhoBanco();

            using (var Connection = new SqlConnection(ConnectionString))
            {
                //var CommandText = $"SELECT Pessoa.NomeUsuario, Pessoa.Email FROM Pessoa, Amizade WHERE  IdPessoaDestino = {pessoa.IdPessoa} AND Pessoa.IdPessoa = Amizade.IdPessoaOrigem AND Aceito = 1";
                var CommandText = $"SELECT * FROM Amizade, Pessoa WHERE Amizade.IdPessoaDestino = {pessoa.IdPessoa} AND IdPessoaOrigem = IdPessoa AND Aceito = 1";
                var SelectCommand = new SqlCommand(CommandText, Connection);

                amigo = null;
                var amigos = new List<Models.Amizade>();

                try
                {
                    Connection.Open();

                    using (var reader = SelectCommand.ExecuteReader(CommandBehavior.CloseConnection))
                    {
                        while (reader.Read())
                        {
                             amigo = new Amizade();

                            amigo.IdPessoaOrigem = (int)reader["IdPessoaOrigem"];
                            amigo.IdPessoaDestino = (int)reader["IdPessoaDestino"];
                            amigo.NomeUsuario = reader["NomeUsuario"].ToString();
                            amigo.Email = reader["Email"].ToString();

                            amigos.Add(amigo);
                        }
                    }
                }
                catch (SqlException se)
                {
                    throw new Exception(se.Message);
                }
                catch (System.Exception e)
                {
                    throw new Exception(e.Message);
                }
                finally
                {
                    Connection.Close();
                }
                return amigos;
            }
        }

        internal void CreateAmizade(int id, Amizade amizade, Pessoa pessoa)
        {
            var ConnectionString = DAO.CaminhoBanco();

            using (var Connection = new SqlConnection(ConnectionString))
            {
                var CommandText = "INSERT INTO Amizade (IdPessoaOrigem, IdPessoaDestino, Aceito, Data) VALUES (@IdPessoaOrigem, @IdPessoaDestino, @Aceito, @Data)";
                var InsertCommand = new SqlCommand(CommandText, Connection);

                InsertCommand.Parameters.AddWithValue("IdPessoaOrigem", pessoa.IdPessoa);
                InsertCommand.Parameters.AddWithValue("IdPessoaDestino", id);
                InsertCommand.Parameters.AddWithValue("Aceito", amizade.Aceito);
                InsertCommand.Parameters.AddWithValue("Data", DateTime.Now);

                try
                {
                    Connection.Open();
                    InsertCommand.ExecuteNonQuery();
                }
                catch (SqlException se)
                {
                    throw new Exception(se.Message);
                }
                catch (System.Exception e)
                {
                    throw new Exception(e.Message);
                }
                finally
                {
                    Connection.Close();
                }
            }
        }

        public static void DeleteAmigo(int id, Pessoa pessoa)
        {
            var ConnectionString = DAO.CaminhoBanco();

            using (var Connection = new SqlConnection(ConnectionString))
            {
                var CommandText = $"DELETE FROM Amizade WHERE IdPessoaOrigem = {id} AND IdPessoaDestino = {pessoa.IdPessoa}";
                var DeleteCommand = new SqlCommand(CommandText, Connection);

                try
                {
                    Connection.Open();
                    DeleteCommand.ExecuteNonQuery();
                }
                catch (SqlException se)
                {
                    throw new Exception(se.Message);
                }
                catch (System.Exception e)
                {
                    throw new Exception(e.Message);
                }
                finally
                {
                    Connection.Close();
                }
            }

            using (var Connection2 = new SqlConnection(ConnectionString))
            {
                var CommandText2 = $"DELETE FROM Amizade WHERE IdPessoaOrigem = {pessoa.IdPessoa} AND IdPessoaDestino = {id}";
                var DeleteCommand2 = new SqlCommand(CommandText2, Connection2);

                try
                {
                    Connection2.Open();
                    DeleteCommand2.ExecuteNonQuery();
                }
                catch (SqlException se)
                {
                    throw new Exception(se.Message);
                }
                catch (System.Exception e)
                {
                    throw new Exception(e.Message);
                }
                finally
                {
                    Connection2.Close();
                }
            }
        }

        internal void AceitarPedidoAmizade(int id, Pessoa pessoa)
        {
            var ConnectionString = DAO.CaminhoBanco();

            using (var Connection = new SqlConnection(ConnectionString))
            {
                var CommandText = $"UPDATE Amizade SET Aceito = 1 WHERE IdPessoaDestino = {pessoa.IdPessoa} AND IdPessoaOrigem = {id}";
                var UpdateCommand = new SqlCommand(CommandText, Connection);

                try
                {
                    Connection.Open();
                    UpdateCommand.ExecuteNonQuery();
                }
                catch (SqlException se)
                {
                    throw new Exception(se.Message);
                }
                catch (System.Exception e)
                {
                    throw new Exception(e.Message);
                }
                finally
                {
                    Connection.Close();
                }
            }

            using (var Connection = new SqlConnection(ConnectionString))
            {
                var CommandText = "INSERT INTO Amizade (IdPessoaOrigem, IdPessoaDestino, Aceito, Data) VALUES (@IdPessoaOrigem, @IdPessoaDestino, @Aceito, @Data)";
                var InsertCommand = new SqlCommand(CommandText, Connection);

                InsertCommand.Parameters.AddWithValue("IdPessoaOrigem", pessoa.IdPessoa);
                InsertCommand.Parameters.AddWithValue("IdPessoaDestino", id);
                InsertCommand.Parameters.AddWithValue("Aceito", true);
                InsertCommand.Parameters.AddWithValue("Data", DateTime.Now);

                try
                {
                    Connection.Open();
                    InsertCommand.ExecuteNonQuery();
                }
                catch (SqlException se)
                {
                    throw new Exception(se.Message);
                }
                catch (System.Exception e)
                {
                    throw new Exception(e.Message);
                }
                finally
                {
                    Connection.Close();
                }
            }
        }

        public static void RecusarPedidoAmizade(int id, Pessoa pessoa)
        {
            var ConnectionString = DAO.CaminhoBanco();

            using (var Connection = new SqlConnection(ConnectionString))
            {
                var CommandText = $"DELETE FROM Amizade WHERE IdPessoaOrigem = {id} AND IdPessoaDestino = {pessoa.IdPessoa}";
                var DeleteCommand = new SqlCommand(CommandText, Connection);

                try
                {
                    Connection.Open();
                    DeleteCommand.ExecuteNonQuery();
                }
                catch (SqlException se)
                {
                    throw new Exception("Erro ao tentar atualizar dados " + se.Message);
                }
                catch (System.Exception e)
                {
                    throw new Exception("Erro inesperado " + e.Message);
                }
                finally
                {
                    Connection.Close();
                }
            }
        }

        public static bool VerificarPedidoAmizadeExistente(int id, Pessoa pessoa)
        {
            var ConnectionString = DAO.CaminhoBanco();

            bool tem = false;

            using (var Connection = new SqlConnection(ConnectionString))
            {
                var CommandText = $"SELECT * FROM Amizade WHERE IdPessoaOrigem = {pessoa.IdPessoa} AND IdPessoaDestino = {id}";
                var SelectCommand = new SqlCommand(CommandText, Connection);

                try
                {
                    Connection.Open();

                    using (var reader = SelectCommand.ExecuteReader(CommandBehavior.CloseConnection))
                    {
                        if (reader.HasRows)
                        {
                            tem = true;
                        }
                    }
                }
                catch (SqlException se)
                {
                    throw new Exception(se.Message);
                }
                catch (System.Exception e)
                {
                    throw new Exception(e.Message);
                }
                finally
                {
                    Connection.Close();
                }
                return tem;
            }
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using SocialMarket.Models;
using SocialMarket.Utils;

namespace SocialMarket.Repository
{
    public class PessoaRepository
    {
        public static IEnumerable<Models.Pessoa> GetAllPessoa(Pessoa pessoa)
        {
            var ConnectionString = DAO.CaminhoBanco();

            using (var Connection = new SqlConnection(ConnectionString))
            {
                var CommandText = $"SELECT * FROM Pessoa WHERE IdPessoa = {pessoa.IdPessoa}";
                var SelectCommand = new SqlCommand(CommandText, Connection);

                //Models.Pessoa pessoa = null;
                var pessoas = new List<Models.Pessoa>();

                try
                {
                    Connection.Open();

                    using (var reader = SelectCommand.ExecuteReader(CommandBehavior.CloseConnection))
                    {
                        while (reader.Read())
                        {
                            pessoa = new Models.Pessoa();

                            pessoa.IdPessoa = (int)reader["IdPessoa"];
                            pessoa.Nome = reader["Nome"].ToString();
                            pessoa.NomeUsuario = reader["NomeUsuario"].ToString();
                            pessoa.Email = reader["Email"].ToString();
                            pessoa.Senha = reader["Senha"].ToString();
                            pessoa.CPF = reader["CPF"].ToString();

                            pessoas.Add(pessoa);
                        }
                    }
                }
                catch (SqlException se)
                {
                    throw new Exception(se.Message);
                }
                catch (System.Exception e)
                {
                    throw new Exception(e.Message);
                }
                finally
                {
                    Connection.Close();
                }
                return pessoas;
            }
        }

        public static IEnumerable<Models.Mercado> ConsultarMercado()
        {
            var ConnectionString = DAO.CaminhoBanco();

            using (var Connection = new SqlConnection(ConnectionString))
            {
                var CommandText = "SELECT * FROM Mercado";
                var SelectCommand = new SqlCommand(CommandText, Connection);

                Models.Mercado mercado = null;
                var mercados = new List<Models.Mercado>();

                try
                {
                    Connection.Open();

                    using (var reader = SelectCommand.ExecuteReader(CommandBehavior.CloseConnection))
                    {
                        while (reader.Read())
                        {
                            mercado = new Models.Mercado();

                            mercado.IdMercado = (int)reader["IdMercado"];
                            mercado.NomeUsuario = reader["NomeUsuario"].ToString();
                            mercado.Email = reader["Email"].ToString();
                            mercado.Telefone = reader["Telefone"].ToString();
                            mercado.CEP = reader["CEP"].ToString();

                            mercados.Add(mercado);
                        }
                    }
                }
                catch (SqlException se)
                {
                    throw new Exception(se.Message);
                }
                catch (System.Exception e)
                {
                    throw new Exception(e.Message);
                }
                finally
                {
                    Connection.Close();
                }
                return mercados;
            }
        }

        public static IEnumerable<Models.Produto> ConsultarPrecoProduto(Mercado mercado)
        {
            var ConnectionString = DAO.CaminhoBanco();

            using (var Connection = new SqlConnection(ConnectionString))
            {
                var CommandText = "SELECT Mercado.NomeUsuario, Produto.Nome, Produto.Fabricante, Produto.Estoque, Produto.Preco FROM Mercado, Produto WHERE Produto.IdMercado = Mercado.IdMercado";
                var SelectCommand = new SqlCommand(CommandText, Connection);

                Models.Produto produto = null;
                var produtos = new List<Models.Produto>();

                try
                {
                    Connection.Open();

                    using (var reader = SelectCommand.ExecuteReader(CommandBehavior.CloseConnection))
                    {
                        while (reader.Read())
                        {
                            produto = new Models.Produto();

                            produto.NomeUsuario = reader["NomeUsuario"].ToString();
                            produto.Nome = reader["Nome"].ToString();
                            produto.Fabricante = reader["Fabricante"].ToString();
                            produto.Estoque = (int)reader["Estoque"];
                            produto.Preco = (decimal)reader["Preco"];

                            produtos.Add(produto);
                        }
                    }
                }
                catch (SqlException se)
                {
                    throw new Exception(se.Message);
                }
                catch (System.Exception e)
                {
                    throw new Exception(e.Message);
                }
                finally
                {
                    Connection.Close();
                }
                return produtos;
            }
        }

        public static Pessoa GetPessoa(int id)
        {
            var ConnectionString = DAO.CaminhoBanco();

            using (var Connection = new SqlConnection(ConnectionString))
            {
                var CommandText = $"SELECT * FROM Pessoa WHERE IdPessoa = {id}";
                var SelectCommand = new SqlCommand(CommandText, Connection);

                Models.Pessoa pessoa = null;

                try
                {
                    Connection.Open();

                    using (var reader = SelectCommand.ExecuteReader(CommandBehavior.CloseConnection))
                    {
                        while (reader.Read())
                        {
                            pessoa = new Models.Pessoa();

                            pessoa.IdPessoa = (int)reader["IdPessoa"];
                            pessoa.Nome = reader["Nome"].ToString();
                            pessoa.NomeUsuario = reader["NomeUsuario"].ToString();
                            pessoa.Email = reader["Email"].ToString();
                            pessoa.ConfirmEmail = reader["Email"].ToString();
                            pessoa.Senha = reader["Senha"].ToString();
                            pessoa.ConfirmSenha = reader["Senha"].ToString();
                            pessoa.CPF = reader["CPF"].ToString();
                        }
                    }
                }
                catch (SqlException se)
                {
                    throw new Exception(se.Message);
                }
                catch (System.Exception e)
                {
                    throw new Exception(e.Message);
                }
                finally
                {
                    Connection.Close();
                }
                return pessoa;
            }
        }

        internal void CreatePessoa(Models.Pessoa pessoa)
        {
            var ConnectionString = DAO.CaminhoBanco();

            using (var Connection = new SqlConnection(ConnectionString))
            {
                var CommandText = "INSERT INTO Pessoa (Nome, NomeUsuario, Email, Senha, CPF) VALUES (@Nome, @NomeUsuario, @Email, @Senha, @CPF)";
                var InsertCommand = new SqlCommand(CommandText, Connection);
                InsertCommand.Parameters.AddWithValue("Nome", pessoa.Nome);
                InsertCommand.Parameters.AddWithValue("NomeUsuario", pessoa.NomeUsuario);
                InsertCommand.Parameters.AddWithValue("Email", pessoa.Email);
                InsertCommand.Parameters.AddWithValue("Senha", pessoa.Senha);
                InsertCommand.Parameters.AddWithValue("CPF", pessoa.CPF);

                try
                {
                    Connection.Open();
                    InsertCommand.ExecuteNonQuery();
                }
                catch (SqlException se)
                {
                    throw new Exception(se.Message);
                }
                catch (System.Exception e)
                {
                    throw new Exception(e.Message);
                }
                finally
                {
                    Connection.Close();
                }
            }
        }

        public static void EditPessoa(Models.Pessoa pessoa)
        {
            var ConnectionString = DAO.CaminhoBanco();

            using (var Connection = new SqlConnection(ConnectionString))
            {
                var CommandText = $"UPDATE Pessoa SET Nome = '{pessoa.Nome}', NomeUsuario = '{pessoa.NomeUsuario}', Email = '{pessoa.Email}', Senha = '{pessoa.Senha}', CPF = '{pessoa.CPF}' WHERE IdPessoa = {pessoa.IdPessoa}";
                var UpdateCommand = new SqlCommand(CommandText, Connection);

                try
                {
                    Connection.Open();
                    UpdateCommand.ExecuteNonQuery();
                }
                catch
                { }
                finally
                {
                    Connection.Close();
                }
            }
        }

        public static void DeletePessoa(int id)
        {
            var ConnectionString = DAO.CaminhoBanco();

            using (var ConnectionAmizade = new SqlConnection(ConnectionString))
            {
                var CommandTextAmizade = $"DELETE FROM Amizade WHERE IdPessoaOrigem = {id}";
                var DeleteCommandAmizade = new SqlCommand(CommandTextAmizade, ConnectionAmizade);

                try
                {
                    ConnectionAmizade.Open();
                    DeleteCommandAmizade.ExecuteNonQuery();
                }
                catch (SqlException se)
                {
                    throw new Exception(se.Message);
                }
                catch (System.Exception e)
                {
                    throw new Exception(e.Message);
                }
                finally
                {
                    ConnectionAmizade.Close();
                }

                using (var Connection = new SqlConnection(ConnectionString))
                {
                    var CommandText = $"DELETE FROM Pessoa WHERE IdPessoa = {id}";
                    var DeleteCommand = new SqlCommand(CommandText, Connection);

                    try
                    {
                        Connection.Open();
                        DeleteCommand.ExecuteNonQuery();
                    }
                    catch (SqlException se)
                    {
                        throw new Exception(se.Message);
                    }
                    catch (System.Exception e)
                    {
                        throw new Exception(e.Message);
                    }
                    finally
                    {
                        Connection.Close();
                    }
                }
            }
        }

        #region Verificar Cadastro Existente Pessoa
        public static bool VerificarCadastroExistentePessoaEmail(Models.Pessoa pessoa)
        {
            var ConnectionString = DAO.CaminhoBanco();

            bool email = false;

            using (var Connection = new SqlConnection(ConnectionString))
            {
                var CommandText = $"SELECT * FROM Pessoa WHERE Email = '{pessoa.Email}'";
                var SelectCommand = new SqlCommand(CommandText, Connection);

                try
                {
                    Connection.Open();

                    using (var reader = SelectCommand.ExecuteReader(CommandBehavior.CloseConnection))
                    {
                        if (reader.HasRows)
                        {
                            email = true;
                        }   
                    }
                }
                catch (SqlException se)
                {
                    throw new Exception(se.Message);
                }
                catch (System.Exception e)
                {
                    throw new Exception(e.Message);
                }
                finally
                {
                    Connection.Close();
                }
                return email;
            }
        }

        public static bool VerificarCadastroExistentePessoaNomeUsuario(Models.Pessoa pessoa)
        {
            var ConnectionString = DAO.CaminhoBanco();

            bool nomeUsuario = false;

            using (var Connection = new SqlConnection(ConnectionString))
            {
                var CommandText = $"SELECT * FROM Pessoa WHERE NomeUsuario = '{pessoa.NomeUsuario}'";
                var SelectCommand = new SqlCommand(CommandText, Connection);

                try
                {
                    Connection.Open();

                    using (var reader = SelectCommand.ExecuteReader(CommandBehavior.CloseConnection))
                    {
                        if (reader.HasRows)
                        {
                            nomeUsuario = true;
                        }
                    }
                }
                catch (SqlException se)
                {
                    throw new Exception(se.Message);
                }
                catch (System.Exception e)
                {
                    throw new Exception(e.Message);
                }
                finally
                {
                    Connection.Close();
                }
                return nomeUsuario;
            }
        }

        public static bool VerificarCadastroExistentePessoaCPF(Models.Pessoa pessoa)
        {
            var ConnectionString = DAO.CaminhoBanco();
            bool cpf = false;

            using (var Connection = new SqlConnection(ConnectionString))
            {
                var CommandText = $"SELECT * FROM Pessoa WHERE CPF = '{pessoa.CPF}'";
                var SelectCommand = new SqlCommand(CommandText, Connection);

                try
                {
                    Connection.Open();

                    using (var reader = SelectCommand.ExecuteReader(CommandBehavior.CloseConnection))
                    {
                        if (reader.HasRows)
                        {
                            cpf = true;
                        }
                    }
                }
                catch (SqlException se)
                {
                    throw new Exception(se.Message);
                }
                catch (System.Exception e)
                {
                    throw new Exception(e.Message);
                }
                finally
                {
                    Connection.Close();
                }
                return cpf;
            }
        }
        #endregion
        
        public Models.Pessoa VerificarLoginPessoa(Models.Pessoa pessoa)
        {
            var ConnectionString = DAO.CaminhoBanco();

            using (var Connection = new SqlConnection(ConnectionString))
            {
                var CommandText = $"SELECT * FROM Pessoa WHERE NomeUsuario = '{pessoa.NomeUsuario}'";
                var SelectCommand = new SqlCommand(CommandText, Connection);

                try
                {
                    Connection.Open();

                    using (var reader = SelectCommand.ExecuteReader(CommandBehavior.CloseConnection))
                    {
                        if (reader.HasRows)
                        {
                            reader.Read();
                            if (Hash.GerarHash(pessoa.Senha) == reader["Senha"].ToString())
                            {

                                pessoa.IdPessoa = (int)reader["IdPessoa"];
                                pessoa.Nome = reader["Nome"].ToString();
                                pessoa.NomeUsuario = reader["NomeUsuario"].ToString();
                                pessoa.Email = reader["Email"].ToString();
                                pessoa.Senha = reader["Senha"].ToString();
                                pessoa.CPF = reader["CPF"].ToString();
                            }
                            else
                            {
                                pessoa = null;
                            }
                        }
                        else
                        {
                            pessoa = null;
                        }
                    }
                }
                catch (SqlException se)
                {
                    throw new Exception(se.Message);
                }
                catch (System.Exception e)
                {
                    throw new Exception(e.Message);
                }
                finally
                {
                    Connection.Close();
                }
                return pessoa;
            }
        }
    }
}
﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SocialMarket.Models
{
    public class Amizade
    {
        public int IdPessoaOrigem { get; set; }
        public int IdPessoaDestino { get; set; }
        public bool Aceito { get; set; }
        public DateTime Data { get; set; }
        public string NomeUsuario { get; set; }
        public string Email { get; set; }
    }
}
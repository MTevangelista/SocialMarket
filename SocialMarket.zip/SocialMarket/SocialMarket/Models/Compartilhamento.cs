﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace SocialMarket.Models
{
    public class Compartilhamento
    {
        public int IdCompartilhamento { get; set; }

        public int IdPostagemPostou { get; set; }

        public int IdPessoaRepostou { get; set; }

        [Required]
        [DisplayFormat(DataFormatString = "{0:d}", ApplyFormatInEditMode = true)]
        [RegularExpression(@"^\d{2}\/\d{2}\/\d{4}", ErrorMessage = "A data deverá estar no formato dd/mm/aaaa")]
        public string DataComp { get; set; }
    }
}
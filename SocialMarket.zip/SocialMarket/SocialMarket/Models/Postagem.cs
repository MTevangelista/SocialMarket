﻿using System;
using System.Data.SqlClient;
using System.Collections.Generic;
using SocialMarket.Models;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Web;

namespace SocialMarket.Models
{
    public class Postagem
    { 
        [Key]
        public int IdPostagem { get; set; }

        public int IdPessoa { get; set; }

        public string NomeUsuario { get; set; }

        [Required(ErrorMessage = "Informe o conteúdo da postagem.")]
        [Display(Name = "Conteúdo")]
        [StringLength(60)]
        [MaxLength(100, ErrorMessage = "O conteúdo deve ter no máximo 100 caracteres.")]
        [DataType(DataType.MultilineText)]
        public string Conteudo { get; set; }

        [Display(Name = "Carregar Mídia")]
        [DataType(DataType.ImageUrl)]
        public string Midia { get; set; }

        [Required]
        [DisplayFormat(DataFormatString = "{0:d}", ApplyFormatInEditMode = true)]
        [RegularExpression(@"^\d{2}\/\d{2}\/\d{4}", ErrorMessage = "A data deverá estar no formato dd/mm/aaaa")]
        public DateTime Data{ get; set; }

        [Display(Name = "Curtidas")]
        public int QuantidadeCurtida { get; set; }

        public string NomeUsuarioRepostou { get; set; }

        //Usado para verificar se o usuário da session já curtiu a postagem (mantendo o botão de curtir azul ou default)
        public string MinhaCurtida { get; set; }

        public DateTime DataComp { get; set; }
    }
}
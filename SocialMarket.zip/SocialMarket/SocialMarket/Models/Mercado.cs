﻿using System.ComponentModel.DataAnnotations;

namespace SocialMarket.Models
{
    public class Mercado
    {
        [Key]
        public int IdMercado { get; set; }

        [Required(ErrorMessage = "Informe o nome do Mercado")]
        [StringLength(60)]
        [MaxLength(100, ErrorMessage = "O nome deve ter até 100 caracteres")]
        public string Nome { get; set; }

        [Required(ErrorMessage = "Informe o Nome de Usuário do Mercado")]
        [Display(Name = "Nome de Usuário")]
        [RegularExpression(@"^[A-Z]+[a-zA-Z\s]*$")]
        [StringLength(60)]
        [MaxLength(70, ErrorMessage = "O nome deve ter até 100 caracteres")]
        public string NomeUsuario { get; set; }

        [Required(ErrorMessage = "Informe seu Email")]
        [EmailAddress]
        [RegularExpression(@"^[a-zA-Z]+(([\'\,\.\- ][a-zA-Z ])?[a-zA-Z]*)*\s+<(\w[-._\w]*\w@\w[-._\w]*\w\.\w{2,3})>$|^(\w[-._\w]*\w@\w[-._\w]*\w\.\w{2,3})$")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Confirme seu Email")]
        [Display(Name = "Confirmar Email")]
        [Compare("Email", ErrorMessage = "E-mail e confirmação não são os mesmos.")]
        public string ConfirmEmail { get; set; }

        [Required(ErrorMessage = "Informe sua Senha")]
        [StringLength(100, ErrorMessage = "{0} deve ter pelo menos {2} caracteres de comprimento.", MinimumLength = 6)]
        //[RegularExpression(@"^.*(?=.{8,})(?=.*[@#$%^&+=])(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).*$", ErrorMessage = "No minimo uma letra maiúscula, uma letra minuscula, um digito (0..9) e um carácter especial (@#$%^&+=).")]
        [DataType(DataType.Password)]
        [Display(Name = "Senha")]
        public string Senha { get; set; }

        [Required(ErrorMessage = "Confirme sua Senha")]
        [DataType(DataType.Password)]
        [Display(Name = "Confirmar senha")]
        [Compare("Senha", ErrorMessage = "Senha e confirmação não são as mesmas.")]
        public string ConfirmSenha { get; set; }

        [Required(ErrorMessage = "Informe seu Telefone")]
        //[DataType(DataType.PhoneNumber)]
        public string Telefone { get; set; }

        [Required(ErrorMessage = "Informe seu CNPJ")]
        public string CNPJ { get; set; }

        [Required(ErrorMessage = "Informe seu CEP")]
        public string CEP { get; set; }
    }
}
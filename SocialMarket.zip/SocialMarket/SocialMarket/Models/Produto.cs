﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace SocialMarket.Models
{
    public class Produto
    {
        [Key]
        public int IdProduto { get; set; }

        public int IdMercado{ get; set; }

        public string NomeUsuario { get; set; }

        [Required(ErrorMessage = "O nome do produto é obrigatório", AllowEmptyStrings = false)]
        public string Nome { get; set; }

        [Required(ErrorMessage = "A nome do fabricante é obrigatório", AllowEmptyStrings = false)]
        public string Fabricante { get; set; }

        [Required(ErrorMessage = "Informe o estoque do produto")]
        public int Estoque { get; set; }

        [Required(ErrorMessage = "Informe o preço do produto", AllowEmptyStrings = false)]
        [Display(Name = "Preço")]
        [DisplayFormat(DataFormatString = "{0:C2}", ApplyFormatInEditMode = true)]
        public decimal Preco { get; set; }
    }
}
﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SocialMarket.Models
{
    public class ListaDeCompra
    {
        public int IdPessoa{ get; set; }

        public int IdItem { get; set; }

        [Required(ErrorMessage = "Informe a Descrição")]
        [Display(Name = "Descrição")]
        [StringLength(60)]
        [MaxLength(100, ErrorMessage = "A Descrição deve ter no máximo 100 caracteres.")]
        public string Descricao { get; set; }

        [Required(ErrorMessage = "Informe o Item da sua lista de compra")]
        [StringLength(60)]
        [MaxLength(70, ErrorMessage = "O Item deve ter no máximo 70 caracteres.")]
        public string Item { get; set; }

        [Required(ErrorMessage = "Informe a Quantidade")]
        public int Quantidade { get; set; }

        public DateTime Data { get; set; }
    }
}
﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SocialMarket.Models
{
    public class Comentario
    {
        public int IdComentario { get; set; }

        public int IdPostagem {get; set; }

        public int IdPessoa { get; set; }

        [Required(ErrorMessage = "Informe o conteúdo do comentário.")]
        [Display(Name = "Conteúdo")]
        [StringLength(60)]
        [MaxLength(100, ErrorMessage = "O conteúdo deve ter no máximo 100 caracteres.")]
        [DataType(DataType.MultilineText)]
        public string Conteudo { get; set; }

        [Required]
        [DisplayFormat(DataFormatString = "{0:d}", ApplyFormatInEditMode = true)]
        [RegularExpression(@"^\d{2}\/\d{2}\/\d{4}", ErrorMessage = "A data deverá estar no formato dd/mm/aaaa")]
        public DateTime Data { get; set; }

        public string NomeUsuario { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SocialMarket.Models
{
    public class Curtida
    {
        public int IdCurtida { get; set; }
        public int IdPostagem { get; set; }
        public int IdPessoaCurtiu { get; set; }
        
    }
}